import { useState, useEffect } from "react";
import JSZip from "jszip";
import * as XLSX from "xlsx";

async function buildZip(entries, zipName) {
  const zip = new JSZip();
  for (const en of entries) {
    try {
      if (en.text !== undefined) {
        zip.file(en.path, en.text);
      } else if (en.blob !== undefined) {
        zip.file(en.path, en.blob);
      } else {
        const res = await fetch(en.url);
        const blob = await res.blob();
        zip.file(en.path, blob);
      }
    } catch (err) {}
  }
  const content = await zip.generateAsync({ type: "blob" });
  const url = URL.createObjectURL(content);
  const a = document.createElement("a");
  a.href = url;
  a.download = zipName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
function stripVoiceMarkers(text) {
  if (!text) return text;
  return text.replace(/\[pausa\]/gi," ").replace(/\[enfasis\]/gi,"").replace(/\[énfasis\]/gi,"").replace(/\s{2,}/g," ").trim();
}
async function concatAudioToWav(urls) {
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  const ctx = new AudioCtx();
  const buffers = [];
  for (const u of urls) {
    try {
      const res = await fetch(u);
      const arr = await res.arrayBuffer();
      const buf = await ctx.decodeAudioData(arr.slice(0));
      buffers.push(buf);
    } catch (err) {}
  }
  if (buffers.length === 0) { ctx.close(); return null; }
  const sampleRate = buffers[0].sampleRate;
  const numChannels = buffers[0].numberOfChannels;
  let totalLength = 0;
  for (const b of buffers) { totalLength += b.length; }
  const out = ctx.createBuffer(numChannels, totalLength, sampleRate);
  let offset = 0;
  for (const b of buffers) {
    for (let ch = 0; ch < numChannels; ch++) {
      const outData = out.getChannelData(ch);
      const srcCh = ch < b.numberOfChannels ? ch : 0;
      outData.set(b.getChannelData(srcCh), offset);
    }
    offset += b.length;
  }
  ctx.close();
  return audioBufferToWavBlob(out);
}
function audioBufferToWavBlob(buffer) {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const numFrames = buffer.length;
  const bytesPerSample = 2;
  const blockAlign = numChannels * bytesPerSample;
  const dataSize = numFrames * blockAlign;
  const arrBuffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(arrBuffer);
  function writeString(offset, str) {
    for (let i = 0; i < str.length; i++) { view.setUint8(offset + i, str.charCodeAt(i)); }
  }
  writeString(0, "RIFF");
  view.setUint32(4, 36 + dataSize, true);
  writeString(8, "WAVE");
  writeString(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true);
  writeString(36, "data");
  view.setUint32(40, dataSize, true);
  let offset = 44;
  const channelData = [];
  for (let ch = 0; ch < numChannels; ch++) { channelData.push(buffer.getChannelData(ch)); }
  for (let i = 0; i < numFrames; i++) {
    for (let ch = 0; ch < numChannels; ch++) {
      let sample = channelData[ch][i];
      sample = Math.max(-1, Math.min(1, sample));
      sample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      view.setInt16(offset, sample, true);
      offset += 2;
    }
  }
  return new Blob([arrBuffer], { type: "audio/wav" });
}
const STOPWORDS_ES=["que","para","esto","pero","con","los","las","del","una","por","como","esta","este","son","hay","muy","mas","sin","tus","tu","yo","tan","fue","ser","han","hace","cada","entre","donde","cuando","desde","sobre","todo","toda","todos","todas","asi","eso","esa","ese","les","nos","the","and","for","you"];
function normalizeWords(text) {
  if (!text) return [];
  const clean = text.toLowerCase().replace(/\[pausa\]/g," ").replace(/\[enfasis\]/g," ").replace(/[^a-zA-ZáéíóúñÁÉÍÓÚÑ\s]/g," ");
  const words = clean.split(/\s+/).filter(function(w){return w.length>3 && STOPWORDS_ES.indexOf(w)===-1;});
  return words;
}
function textSimilarity(a, b) {
  const wa=normalizeWords(a);
  const wb=normalizeWords(b);
  if (wa.length===0 || wb.length===0) return 0;
  const setA={};
  wa.forEach(function(w){setA[w]=true;});
  const setB={};
  wb.forEach(function(w){setB[w]=true;});
  let inter=0;
  for (const w in setA) { if (setB[w]) inter++; }
  const union=Object.keys(Object.assign({},setA,setB)).length;
  return union===0?0:inter/union;
}
function sugerirRitmo(guion) {
  if (!guion) return null;
  const clean = guion.replace(/\[pausa\]/gi,"").replace(/\[enfasis\]/gi,"");
  const sentences = clean.split(/[.!?]+/).map(function(s){return s.trim();}).filter(function(s){return s.length>0;});
  if (sentences.length===0) return null;
  let totalWords=0;
  sentences.forEach(function(s){totalWords+=s.split(/\s+/).filter(function(w){return w.length>0;}).length;});
  const avg=totalWords/sentences.length;
  const hasNumbers=/\d/.test(clean);
  const enfasisCount=(guion.match(/\[enfasis\]/gi)||[]).length;
  const impacto=avg<9||hasNumbers||enfasisCount>=2;
  return impacto?{tipo:"Impacto",rango:"1.5–2.5s por clip",icon:"⚡"}:{tipo:"Reflexivo",rango:"4–6s por clip",icon:"🌊"};
}
function parseAIJson(text) {
  const clean = (text || "").replace(/```json|```/g, "").trim();
  try {
    return JSON.parse(clean);
  } catch (err) {
    throw new Error("La respuesta de la IA llego incompleta o no es JSON valido. Prueba de nuevo, o si persiste, reduce la duracion/cantidad de escenas.");
  }
}
function getBusquedaTerm(e, kind) {
  if (!e || !e.busqueda_clip) return "";
  if (typeof e.busqueda_clip === "string") return e.busqueda_clip;
  return e.busqueda_clip[kind] || e.busqueda_clip.literal || e.busqueda_clip.metaforica || e.busqueda_clip.textura || "";
}
function padNum(n) { return n < 10 ? "0" + n : "" + n; }
function extFromUrl(url) {
  if (!url) return "mp4";
  if (url.indexOf("data:audio/wav") === 0) return "wav";
  if (url.indexOf("data:audio/mpeg") === 0) return "mp3";
  const clean = url.split("?")[0];
  const m = clean.match(/\.(\w+)$/);
  return m ? m[1] : "mp4";
}

const STORAGE_KEY = "viralscript_config";
function loadConfig() {
  try { const raw = localStorage.getItem(STORAGE_KEY); return raw ? JSON.parse(raw) : null; } catch { return null; }
}
function saveConfig(cfg) { localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg)); }

const CHANNELS_KEY = "viralscript_channels";
function loadChannels() {
  try { const raw = localStorage.getItem(CHANNELS_KEY); return raw ? JSON.parse(raw) : []; } catch { return []; }
}
function saveChannels(channels) { localStorage.setItem(CHANNELS_KEY, JSON.stringify(channels)); }
const ACTIVE_CHANNEL_KEY = "viralscript_active_channel";
function loadActiveChannelId() {
  try { return localStorage.getItem(ACTIVE_CHANNEL_KEY) || null; } catch { return null; }
}
function saveActiveChannelId(id) { localStorage.setItem(ACTIVE_CHANNEL_KEY, id); }

const QUEUE_KEY = "viralscript_queue";
function loadQueue() {
  try { const raw = localStorage.getItem(QUEUE_KEY); return raw ? JSON.parse(raw) : []; } catch { return []; }
}
function saveQueue(q) { localStorage.setItem(QUEUE_KEY, JSON.stringify(q)); }
function parseScriptExcel(file) {
  return new Promise(function (resolve, reject) {
    const reader = new FileReader();
    reader.onload = function (e) {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });
        const items = rows
          .map(function (r) {
            const guion = r.Guion || r.guion || r.GUION || "";
            if (!guion.toString().trim()) return null;
            return {
              id: "q_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8),
              guion: guion.toString().trim(),
              canal: (r.Canal || r.canal || "").toString().trim(),
              idioma: (r.Idioma || r.idioma || "").toString().trim(),
              estilo: (r.Estilo || r.estilo || "").toString().trim(),
              estado: "Pendiente",
            };
          })
          .filter(Boolean);
        resolve(items);
      } catch (err) {
        reject(new Error("No se pudo leer el archivo. Verifica que sea un .xlsx valido con una columna 'Guion'."));
      }
    };
    reader.onerror = function () { reject(new Error("Error leyendo el archivo.")); };
    reader.readAsArrayBuffer(file);
  });
}

const LANGUAGES = [
  { code: "es-latam", label: "Español neutro latinoamericano" },
  { code: "es-es", label: "Español (España)" },
  { code: "en", label: "English" },
  { code: "pt", label: "Português" },
];
const STYLES = [
  { code: "reflexivo", label: "Reflexivo y profundo" },
  { code: "motivacional", label: "Motivacional y energético" },
  { code: "espiritual", label: "Espiritual y sereno" },
  { code: "narrativo", label: "Narrativo y evocador" },
];

async function searchYouTube(query, config, filters = {}) {
  const params = new URLSearchParams({ part: "snippet", q: query, type: "video", maxResults: 20, key: config.youtubeKey, relevanceLanguage: filters.language || "es", videoDuration: filters.duration || "any", order: "viewCount" });
  const res = await fetch("https://www.googleapis.com/youtube/v3/search?" + params);
  if (!res.ok) throw new Error("Error con la API de YouTube.");
  return (await res.json()).items || [];
}
async function getVideoStats(videoIds, config) {
  const res = await fetch("https://www.googleapis.com/youtube/v3/videos?part=statistics,contentDetails,snippet&id=" + videoIds.join(",") + "&key=" + config.youtubeKey);
  if (!res.ok) throw new Error("Error obteniendo estadísticas.");
  return (await res.json()).items || [];
}
async function getChannelStats(channelIds, config) {
  const res = await fetch("https://www.googleapis.com/youtube/v3/channels?part=statistics&id=" + channelIds.join(",") + "&key=" + config.youtubeKey);
  if (!res.ok) throw new Error("Error obteniendo datos del canal.");
  return (await res.json()).items || [];
}
async function searchPexels(query, config) {
  const res = await fetch("https://api.pexels.com/videos/search?query=" + encodeURIComponent(query) + "&per_page=6&orientation=portrait", { headers: { Authorization: config.pexelsKey } });
  if (!res.ok) return [];
  return (await res.json()).videos || [];
}
async function searchPixabay(query, config) {
  const res = await fetch("https://pixabay.com/api/videos/?key=" + config.pixabayKey + "&q=" + encodeURIComponent(query) + "&per_page=6");
  if (!res.ok) return [];
  return (await res.json()).hits || [];
}
async function searchFreesoundMusic(query, config) {
  const params = new URLSearchParams({
    query: query,
    token: config.freesoundKey,
    fields: "id,name,previews,duration,license",
    filter: "duration:[15 TO 400]",
    page_size: "6",
  });
  const res = await fetch("https://freesound.org/apiv2/search/text/?" + params);
  if (!res.ok) return [];
  const data = await res.json();
  return data.results || [];
}
let _wakeLock=null;
async function acquireWakeLock() {
  try {
    if ("wakeLock" in navigator) { _wakeLock = await navigator.wakeLock.request("screen"); }
  } catch (err) {}
}
async function releaseWakeLock() {
  try {
    if (_wakeLock) { await _wakeLock.release(); _wakeLock=null; }
  } catch (err) {}
}
async function fetchWithRetry(url, options, retries) {
  const n = retries===undefined?2:retries;
  for (let i=0; i<=n; i++) {
    try {
      return await fetch(url, options);
    } catch (err) {
      if (i===n) throw new Error("Se perdio la conexion con el servidor. Revisa tu wifi/datos e intenta de nuevo.");
      await new Promise(function(r){setTimeout(r, 1200*(i+1));});
    }
  }
}
async function callClaude(prompt, config) {
  const res = await fetchWithRetry("/api/claude", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ apiKey: config.anthropicKey, messages: [{ role: "user", content: prompt }] }),
  });
  const data = await res.json();
  if (!res.ok || data.error) throw new Error(data.error || "Error con la API de Anthropic.");
  return data.content?.[0]?.text || "";
}
async function getElevenLabsVoices(config) {
  const res = await fetch("/api/elevenlabs", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "voices", apiKey: config.elevenlabsKey }),
  });
  if (!res.ok) throw new Error("Error obteniendo voces de ElevenLabs.");
  const data = await res.json();
  return data.voices || [];
}
async function speakElevenOnce(text, voiceId, apiKey) {
  const res = await fetch("/api/elevenlabs", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "speak", apiKey: apiKey, voiceId: voiceId, text: text }),
  });
  const data = await res.json();
  if (!res.ok || data.error) throw new Error(data.error || "Error generando audio. Verifica tu API key o si se agotaron tus creditos gratuitos de ElevenLabs.");
  return "data:audio/mpeg;base64," + data.audioBase64;
}
// Si la clave principal falla (creditos agotados, clave invalida) y hay una clave
// de respaldo, se reintenta con la de respaldo. Nota: los IDs de voces por defecto
// son los mismos en todas las cuentas; las voces clonadas/propias no.
async function generateSpeech(text, voiceId, config) {
  try {
    return await speakElevenOnce(text, voiceId, config.elevenlabsKey);
  } catch (err) {
    if (!config.elevenlabsKey2) throw err;
    try {
      return await speakElevenOnce(text, voiceId, config.elevenlabsKey2);
    } catch (err2) {
      throw new Error("Fallaron las dos claves de ElevenLabs. Principal: " + err.message + " | Respaldo: " + err2.message);
    }
  }
}
const GEMINI_VOICE_DESC={
  Zephyr:"Brillante y clara",Puck:"Enérgica y alegre",Charon:"Informativa, tipo narrador",Kore:"Firme y segura",Fenrir:"Excitable, muy expresiva",
  Leda:"Juvenil y fresca",Orus:"Firme, tono serio",Aoede:"Fresca y ligera",Callirrhoe:"Relajada, tono conversacional",Autonoe:"Brillante y optimista",
  Enceladus:"Susurrante, muy suave",Iapetus:"Clara y articulada",Umbriel:"Relajada y neutra",Algieba:"Suave y agradable",Despina:"Suave y fluida",
  Erinome:"Clara y precisa",Algenib:"Grave y rasposa",Rasalgethi:"Informativa, tono profesional",Laomedeia:"Enérgica y animada",
  Achernar:"Suave y delicada",Alnilam:"Firme y fuerte",Schedar:"Pareja, tono estable",Gacrux:"Madura y con experiencia",Pulcherrima:"Directa y expresiva",
  Achird:"Amigable y cercana",Zubenelgenubi:"Casual, tono relajado",Vindemiatrix:"Gentil y cálida",Sadachbia:"Animada y vivaz",
  Sadaltager:"Con autoridad, tono experto",Sulafat:"Cálida y acogedora"
};
async function getGeminiVoices(config) {
  const res = await fetch("/api/gemini-tts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "voices", apiKey: config.geminiKey }),
  });
  if (!res.ok) throw new Error("Error obteniendo voces de Gemini.");
  const data = await res.json();
  return data.voices || [];
}
async function generateSpeechGemini(text, voiceName, config) {
  const res = await fetch("/api/gemini-tts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "speak", apiKey: config.geminiKey, voiceId: voiceName, text: text }),
  });
  const data = await res.json();
  if (!res.ok || data.error) throw new Error(data.error || "Error generando audio con Gemini. Verifica tu API key.");
  return "data:audio/wav;base64," + data.audioBase64;
}

// ---------- Cartesia (voz opcional) ----------
function cartesiaLang(code) {
  if (!code) return "es";
  if (code.indexOf("es") === 0) return "es";
  if (code.indexOf("pt") === 0) return "pt";
  if (code.indexOf("en") === 0) return "en";
  return "es";
}
async function getCartesiaVoices(config) {
  const res = await fetch("/api/cartesia", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "voices", apiKey: config.cartesiaKey, language: cartesiaLang(config.language) }),
  });
  const data = await res.json();
  if (!res.ok || data.error) throw new Error("Error obteniendo voces de Cartesia.");
  return data.voices || [];
}
async function generateSpeechCartesia(text, voiceId, config) {
  const res = await fetch("/api/cartesia", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "speak", apiKey: config.cartesiaKey, voiceId: voiceId, text: text, language: cartesiaLang(config.language) }),
  });
  const data = await res.json();
  if (!res.ok || data.error) throw new Error(data.error || "Error generando audio con Cartesia. Verifica tu API key o tus creditos.");
  return "data:audio/mpeg;base64," + data.audioBase64;
}

// ---------- Proveedores de voz ----------
const VOICE_PROVIDERS = [
  { code: "eleven", label: "ElevenLabs", key: "elevenlabsKey" },
  { code: "gemini", label: "Google Gemini", key: "geminiKey" },
  { code: "cartesia", label: "Cartesia", key: "cartesiaKey" },
];
function availableProviders(config) {
  return VOICE_PROVIDERS.filter(function (pr) { return config && config[pr.key]; });
}
function defaultProvider(config) {
  const av = availableProviders(config);
  return av.length ? av[0].code : "eleven";
}
async function loadVoicesFor(provider, config) {
  if (provider === "eleven") return await getElevenLabsVoices(config);
  if (provider === "gemini") {
    const names = await getGeminiVoices(config);
    return names.map(function (n) { return { voice_id: n, name: n, desc: GEMINI_VOICE_DESC[n] || "" }; });
  }
  if (provider === "cartesia") return await getCartesiaVoices(config);
  return [];
}

// ---------- Cache de audio (IndexedDB) ----------
// Si el mismo texto se pide con el mismo proveedor y la misma voz, se devuelve
// el audio guardado en vez de volver a gastar creditos.
const AUDIO_DB = "viralscript_audio_cache";
const AUDIO_STORE = "audios";
const AUDIO_CACHE_MAX = 400;
function openAudioDb() {
  return new Promise(function (resolve, reject) {
    if (!window.indexedDB) return reject(new Error("sin indexedDB"));
    const req = window.indexedDB.open(AUDIO_DB, 1);
    req.onupgradeneeded = function () { req.result.createObjectStore(AUDIO_STORE, { keyPath: "k" }); };
    req.onsuccess = function () { resolve(req.result); };
    req.onerror = function () { reject(req.error); };
  });
}
async function audioCacheKey(provider, voiceId, text) {
  const raw = provider + "|" + voiceId + "|" + text.trim();
  try {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw));
    return Array.from(new Uint8Array(buf)).map(function (b) { return b.toString(16).padStart(2, "0"); }).join("");
  } catch (e) {
    let h = 0; for (let i = 0; i < raw.length; i++) { h = ((h << 5) - h + raw.charCodeAt(i)) | 0; }
    return "h" + h + "_" + raw.length;
  }
}
async function audioCacheGet(key) {
  try {
    const db = await openAudioDb();
    return await new Promise(function (resolve) {
      const r = db.transaction(AUDIO_STORE, "readonly").objectStore(AUDIO_STORE).get(key);
      r.onsuccess = function () { resolve(r.result ? r.result.url : null); };
      r.onerror = function () { resolve(null); };
    });
  } catch (e) { return null; }
}
async function audioCachePut(key, url) {
  try {
    const db = await openAudioDb();
    const store = db.transaction(AUDIO_STORE, "readwrite").objectStore(AUDIO_STORE);
    store.put({ k: key, url: url, t: Date.now() });
    const all = store.getAll();
    all.onsuccess = function () {
      const items = all.result || [];
      if (items.length > AUDIO_CACHE_MAX) {
        items.sort(function (a, b) { return a.t - b.t; });
        items.slice(0, items.length - AUDIO_CACHE_MAX).forEach(function (it) { store.delete(it.k); });
      }
    };
  } catch (e) {}
}
async function audioCacheCount() {
  try {
    const db = await openAudioDb();
    return await new Promise(function (resolve) {
      const r = db.transaction(AUDIO_STORE, "readonly").objectStore(AUDIO_STORE).count();
      r.onsuccess = function () { resolve(r.result || 0); };
      r.onerror = function () { resolve(0); };
    });
  } catch (e) { return 0; }
}
async function audioCacheClear() {
  try {
    const db = await openAudioDb();
    db.transaction(AUDIO_STORE, "readwrite").objectStore(AUDIO_STORE).clear();
  } catch (e) {}
}
// Punto unico para generar voz: revisa el cache, si no esta llama al proveedor.
async function speak(provider, text, voiceId, config) {
  const key = await audioCacheKey(provider, voiceId, text);
  const cached = await audioCacheGet(key);
  if (cached) return cached;
  let url;
  if (provider === "gemini") url = await generateSpeechGemini(text, voiceId, config);
  else if (provider === "cartesia") url = await generateSpeechCartesia(text, voiceId, config);
  else url = await generateSpeech(text, voiceId, config);
  await audioCachePut(key, url);
  return url;
}

// ---------- Estilo del canal (se inyecta en los prompts) ----------
function buildChannelStyleLine(config) {
  const parts = [];
  if (config.channelTone && config.channelTone.trim()) parts.push("tono de narracion: " + config.channelTone.trim());
  if (config.channelRhythm && config.channelRhythm.trim()) parts.push("ritmo: " + config.channelRhythm.trim());
  if (config.channelPalette && config.channelPalette.trim()) parts.push("paleta visual para prompt_video y busqueda_clip: " + config.channelPalette.trim());
  if (!parts.length) return "";
  return "\nESTILO FIJO DEL CANAL (respetalo siempre, es la identidad del canal): " + parts.join("; ") + ".";
}

function parseDuration(iso) {
  const m = iso && iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!m) return 0;
  return (parseInt(m[1]||0)*3600)+(parseInt(m[2]||0)*60)+(parseInt(m[3]||0));
}
function formatDuration(s) {
  const h=Math.floor(s/3600),m=Math.floor((s%3600)/60),sc=s%60;
  return h>0?h+"h "+m+"m":m+"m "+sc+"s";
}
function formatNumber(n) {
  if(!n)return"0";const num=parseInt(n);
  if(num>=1000000)return(num/1000000).toFixed(1)+"M";
  if(num>=1000)return(num/1000).toFixed(1)+"K";
  return num.toString();
}
function outlierScore(views,subs){return(!subs||subs===0)?0:(views/subs).toFixed(1);}

let ffmpegInstance=null;
function loadScript(src){
  return new Promise(function(resolve,reject){
    const s=document.createElement("script");
    s.src=src;
    s.type="module";
    s.onload=resolve;
    s.onerror=reject;
    document.head.appendChild(s);
  });
}
async function loadFFmpegLib(){
  if(ffmpegInstance)return ffmpegInstance;
  if(!window.__ffmpegWasmReady){
    const wrapperCode=[
      "import { FFmpeg } from 'https://esm.sh/@ffmpeg/ffmpeg@0.12.10';",
      "import { toBlobURL, fetchFile } from 'https://esm.sh/@ffmpeg/util@0.12.1';",
      "window.__FFmpegClass = FFmpeg;",
      "window.__ffmpegToBlobURL = toBlobURL;",
      "window.__ffmpegFetchFile = fetchFile;",
      "window.__ffmpegWasmReady = true;",
      "window.dispatchEvent(new Event('ffmpegwasmready'));"
    ].join("\n");
    const blob=new Blob([wrapperCode],{type:"text/javascript"});
    const url=URL.createObjectURL(blob);
    await new Promise(function(resolve,reject){
      window.addEventListener("ffmpegwasmready",resolve,{once:true});
      loadScript(url).catch(reject);
      setTimeout(function(){reject(new Error("Tiempo de espera agotado cargando FFmpeg."));},30000);
    });
  }
  const ffmpeg=new window.__FFmpegClass();
  const baseURL="https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm";
  await ffmpeg.load({
    coreURL: await window.__ffmpegToBlobURL(baseURL+"/ffmpeg-core.js","text/javascript"),
    wasmURL: await window.__ffmpegToBlobURL(baseURL+"/ffmpeg-core.wasm","application/wasm"),
  });
  ffmpegInstance={ffmpeg:ffmpeg,fetchFile:window.__ffmpegFetchFile};
  return ffmpegInstance;
}

async function assembleVideo(clipsWithDuration, audioUrl, logoDataUrl, musicUrl, onProgress){
  const inst=await loadFFmpegLib();
  const ffmpeg=inst.ffmpeg;
  const fetchFile=inst.fetchFile;

  onProgress("Descargando clips...");
  const clipNames=[];
  for(let i=0;i<clipsWithDuration.length;i++){
    const c=clipsWithDuration[i];
    const name="clip"+i+".mp4";
    const data=await fetchFile(c.url);
    await ffmpeg.writeFile(name,data);
    clipNames.push(name);
  }

  onProgress("Preparando audio...");
  let hasNarration=false;
  if(audioUrl){
    const audioData=await fetchFile(audioUrl);
    await ffmpeg.writeFile("narracion.mp3",audioData);
    hasNarration=true;
  }

  let hasMusic=false;
  if(musicUrl){
    try{
      const musicData=await fetchFile(musicUrl);
      await ffmpeg.writeFile("musica.mp3",musicData);
      hasMusic=true;
    }catch(err){}
  }

  let hasLogo=false;
  if(logoDataUrl){
    try{
      const logoData=await fetchFile(logoDataUrl);
      await ffmpeg.writeFile("logo.png",logoData);
      hasLogo=true;
    }catch(err){}
  }

  onProgress("Uniendo clips...");
  const listContent=clipNames.map(function(n){return "file '"+n+"'";}).join("\n");
  await ffmpeg.writeFile("list.txt",listContent);
  await ffmpeg.exec(["-f","concat","-safe","0","-i","list.txt","-c","copy","-y","concat.mp4"]);

  const totalDuration=clipsWithDuration.reduce(function(sum,c){return sum+(c.duration||5);},0);

  let videoWithWatermark="concat.mp4";
  if(hasLogo){
    onProgress("Aplicando marca de agua...");
    const appearances=Math.min(5,Math.max(3,Math.floor(totalDuration/8)));
    const windows=[];
    for(let i=0;i<appearances;i++){
      const slot=(totalDuration/appearances)*i;
      const jitter=Math.random()*(totalDuration/appearances*0.5);
      const start=Math.min(totalDuration-3,slot+jitter);
      const end=start+2.5;
      windows.push("between(t,"+start.toFixed(1)+","+end.toFixed(1)+")");
    }
    const enableExpr=windows.join("+");
    await ffmpeg.exec([
      "-i","concat.mp4",
      "-i","logo.png",
      "-filter_complex",
      "[1:v]scale=120:-1[wm];[0:v][wm]overlay=W-w-24:H-h-24:enable='"+enableExpr+"'[vout]",
      "-map","[vout]","-map","0:a?",
      "-c:a","copy",
      "-y","watermarked.mp4",
    ]);
    videoWithWatermark="watermarked.mp4";
  }

  onProgress("Mezclando audio...");
  let finalAudioArgs=[];
  if(hasNarration&&hasMusic){
    await ffmpeg.exec([
      "-i","narracion.mp3",
      "-i","musica.mp3",
      "-filter_complex",
      "[1:a]volume=0.15,aloop=loop=-1:size=2e9[bg];[0:a][bg]amix=inputs=2:duration=first:dropout_transition=2[aout]",
      "-map","[aout]",
      "-y","audio_final.mp3",
    ]);
    finalAudioArgs=["-i","audio_final.mp3","-map","0:v:0","-map","1:a:0","-shortest"];
  }else if(hasNarration){
    finalAudioArgs=["-i","narracion.mp3","-map","0:v:0","-map","1:a:0","-shortest"];
  }else{
    finalAudioArgs=["-map","0:v:0"];
  }

  onProgress("Finalizando...");
  await ffmpeg.exec(["-i",videoWithWatermark].concat(finalAudioArgs).concat(["-c:v","copy","-y","final.mp4"]));

  const outputData=await ffmpeg.readFile("final.mp4");
  const blob=new Blob([outputData.buffer],{type:"video/mp4"});
  return URL.createObjectURL(blob);
}

const C = {
  bg:"#0a0a0f",surf:"#111118",card:"#16161f",bord:"#222230",
  acc:"#6c3fff",accS:"#6c3fff22",accH:"#8b5fff",
  gold:"#f0b429",goldS:"#f0b42922",
  txt:"#e8e8f0",muted:"#7878a0",dim:"#4a4a6a",
  ok:"#22c55e",err:"#ef4444",tag:"#1e1e2e",
};

const css = "@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=Inter:wght@300;400;500;600&display=swap');"
+ "html{width:100%;overflow-x:hidden;}"
+ "*{box-sizing:border-box;margin:0;padding:0;}"
+ "body{background:#0a0a0f;color:#e8e8f0;font-family:'Inter',sans-serif;min-height:100vh;width:100%;overflow-x:hidden;}"
+ ".app{display:flex;min-height:100vh;width:100%;overflow-x:hidden;}"
+ ".sidebar{width:220px;min-height:100vh;background:#111118;border-right:1px solid #222230;display:flex;flex-direction:column;padding:24px 0;position:fixed;top:0;left:0;z-index:100;}"
+ ".slogo{padding:0 20px 28px;border-bottom:1px solid #222230;margin-bottom:16px;}"
+ ".ltxt{font-family:'Syne',sans-serif;font-size:20px;font-weight:800;letter-spacing:-0.5px;}"
+ ".lacc{color:#6c3fff;}"
+ ".lsub{font-size:11px;color:#7878a0;margin-top:2px;letter-spacing:0.5px;}"
+ ".nitem{display:flex;align-items:center;gap:10px;padding:10px 20px;cursor:pointer;font-size:13.5px;font-weight:500;color:#7878a0;transition:all 0.15s;border-left:3px solid transparent;margin:1px 0;}"
+ ".nitem:hover,.nitem.active{background:#6c3fff22;color:#e8e8f0;border-left-color:#6c3fff;}"
+ ".main{margin-left:220px;flex:1;padding:32px 36px;min-height:100vh;}"
+ ".ptitle{font-family:'Syne',sans-serif;font-size:26px;font-weight:700;letter-spacing:-0.5px;margin-bottom:4px;}"
+ ".psub{color:#7878a0;font-size:14px;margin-bottom:28px;}"
+ ".card{background:#16161f;border:1px solid #222230;border-radius:12px;padding:20px;margin-bottom:16px;transition:border-color 0.2s;}"
+ ".card:hover{border-color:#6c3fff;}"
+ ".lbl{font-size:12px;font-weight:600;color:#7878a0;text-transform:uppercase;letter-spacing:0.8px;margin-bottom:6px;display:block;}"
+ ".inp{width:100%;background:#111118;border:1px solid #222230;border-radius:8px;padding:10px 14px;color:#e8e8f0;font-size:14px;font-family:'Inter',sans-serif;outline:none;transition:border-color 0.15s;}"
+ ".inp:focus{border-color:#6c3fff;}"
+ ".inp::placeholder{color:#4a4a6a;}"
+ ".btn{padding:10px 20px;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;border:none;transition:all 0.15s;font-family:'Inter',sans-serif;display:inline-flex;align-items:center;gap:8px;}"
+ ".bp{background:#6c3fff;color:white;}.bp:hover{background:#8b5fff;}.bp:disabled{opacity:0.4;cursor:not-allowed;}"
+ ".bs{background:#1e1e2e;color:#e8e8f0;border:1px solid #222230;}.bs:hover{border-color:#6c3fff;}"
+ ".bg{background:#f0b429;color:#0a0a0f;}.bg:hover{background:#f5c842;}"
+ ".g2{display:grid;grid-template-columns:1fr 1fr;gap:16px;}"
+ ".g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;}"
+ ".tag{display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600;background:#1e1e2e;color:#7878a0;border:1px solid #222230;}"
+ ".ta{background:#6c3fff22;color:#6c3fff;border-color:#6c3fff44;}"
+ ".tg{background:#f0b42922;color:#f0b429;border-color:#f0b42944;}"
+ ".tok{background:#22c55e22;color:#22c55e;border-color:#22c55e44;}"
+ ".srow{display:flex;gap:20px;flex-wrap:wrap;margin:10px 0;}"
+ ".sc{background:#111118;border:1px solid #222230;border-radius:10px;padding:16px;margin-bottom:12px;}"
+ ".sh{display:flex;align-items:center;gap:10px;margin-bottom:12px;}"
+ ".sn{width:28px;height:28px;background:#6c3fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:white;flex-shrink:0;}"
+ ".stxt{background:#0a0a0f;border-radius:8px;padding:12px;font-size:14px;line-height:1.6;color:#e8e8f0;margin-bottom:10px;white-space:pre-wrap;}"
+ ".pbox{background:#0d1117;border:1px dashed #222230;border-radius:8px;padding:10px 12px;font-size:12px;color:#7878a0;font-family:monospace;line-height:1.5;margin-bottom:8px;}"
+ ".alert{padding:12px 16px;border-radius:8px;font-size:13px;margin-bottom:16px;display:flex;align-items:flex-start;gap:10px;}"
+ ".aerr{background:#ef444420;border:1px solid #ef444444;color:#fca5a5;}"
+ ".aok{background:#22c55e20;border:1px solid #22c55e44;color:#86efac;}"
+ ".ainf{background:#6c3fff22;border:1px solid #6c3fff44;color:#a78bfa;}"
+ ".loader{display:flex;flex-direction:column;align-items:center;gap:16px;padding:48px;color:#7878a0;font-size:14px;}"
+ ".spin{width:36px;height:36px;border:3px solid #222230;border-top-color:#6c3fff;border-radius:50%;animation:spin 0.8s linear infinite;}"
+ "@keyframes spin{to{transform:rotate(360deg);}}"
+ ".vc{background:#16161f;border:1px solid #222230;border-radius:10px;overflow:hidden;cursor:pointer;transition:all 0.2s;}"
+ ".vc:hover{border-color:#6c3fff;transform:translateY(-2px);}"
+ ".vt{position:relative;aspect-ratio:16/9;background:#111118;overflow:hidden;}"
+ ".vt img{width:100%;height:100%;object-fit:cover;}"
+ ".vd{position:absolute;bottom:6px;right:6px;background:rgba(0,0,0,0.85);color:white;font-size:11px;font-weight:600;padding:2px 6px;border-radius:4px;}"
+ ".ob{position:absolute;top:6px;left:6px;background:#f0b429;color:#0a0a0f;font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;}"
+ ".vi{padding:12px;}"
+ ".vtit{font-size:13px;font-weight:500;line-height:1.4;margin-bottom:8px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}"
+ ".frow{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px;align-items:flex-end;}"
+ ".fi{display:flex;flex-direction:column;min-width:140px;}"
+ ".kwr{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;}"
+ ".kw{padding:4px 12px;border-radius:20px;font-size:12px;background:#6c3fff22;color:#6c3fff;border:1px solid #6c3fff33;cursor:pointer;}"
+ ".kw:hover,.kw.sel{background:#6c3fff;color:white;}"
+ ".cgrid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:10px;}"
+ ".ci{border-radius:6px;overflow:hidden;aspect-ratio:9/16;background:#111118;position:relative;}"
+ ".ci video{width:100%;height:100%;object-fit:cover;}"
+ ".csrc{position:absolute;bottom:4px;right:4px;font-size:9px;background:rgba(0,0,0,0.7);color:white;padding:1px 5px;border-radius:3px;}"
+ ".cbtn{background:transparent;border:1px solid #222230;color:#7878a0;font-size:11px;padding:3px 8px;border-radius:5px;cursor:pointer;}"
+ ".cbtn:hover{border-color:#6c3fff;color:#6c3fff;}"
+ ".div{height:1px;background:#222230;margin:20px 0;}"
+ ".tabs{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;}"
+ ".tab{padding:10px 18px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;border:1px solid #222230;background:#16161f;color:#7878a0;transition:all 0.15s;}"
+ ".tab.active{background:#6c3fff;color:white;border-color:#6c3fff;}"
+ ".chcard{background:#111118;border:2px solid #222230;border-radius:10px;padding:16px;margin-bottom:12px;position:relative;}"
+ ".chcard.chactive{border-color:#22c55e;background:#22c55e0d;}"
+ ".chbadge{position:absolute;top:12px;right:12px;font-size:10px;font-weight:700;background:#22c55e;color:#0a0a0f;padding:3px 10px;border-radius:20px;}"
+ ".modal{position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.7);display:flex;align-items:flex-start;justify-content:center;z-index:1000;padding:20px 16px;overflow-y:auto;}"
+ ".modalbox{background:#16161f;border:1px solid #222230;border-radius:14px;padding:22px;max-width:520px;width:100%;margin-top:20px;margin-bottom:20px;}"
+ "@media(max-width:900px){.sidebar{width:56px;}.slogo .ltxt,.slogo .lsub,.nitem span{display:none;}.nitem{justify-content:center;padding:12px 0;}.main{margin-left:56px;padding:16px 14px;width:calc(100% - 56px);}.g2,.g3{grid-template-columns:1fr;}.frow{flex-direction:column;align-items:stretch;}.fi{min-width:100%;}.ptitle{font-size:20px;}.cgrid{grid-template-columns:repeat(2,1fr);}}";
function CopyBtn(props){
  const text = props.text;
  const [c,setC]=useState(false);
  return <button className="cbtn" onClick={function(){navigator.clipboard.writeText(text);setC(true);setTimeout(function(){setC(false);},1500);}}>{c?"✓ Copiado":"Copiar"}</button>;
}

function Sidebar(props){
  const page = props.page, setPage = props.setPage, configured = props.configured;
  const [activeName,setActiveName]=useState("");
  useEffect(function(){
    const channels=loadChannels();
    const activeId=loadActiveChannelId();
    const active=channels.find(function(c){return c.id===activeId;});
    setActiveName(active?active.name:"");
  },[page]);
  const nav=[
    {id:"config",icon:"⚙️",label:"Configuración"},
    {id:"research",icon:"🔍",label:"Investigar Nichos",req:true},
    {id:"analyzer",icon:"🎯",label:"Analizar Video",req:true},
    {id:"shorts",icon:"⚡",label:"Generar Shorts",req:true},
    {id:"longform",icon:"📽️",label:"Videos Largos",req:true},
  ];
  return(
    <div className="sidebar">
      <div className="slogo">
        <div className="ltxt"><span className="lacc">Viral</span>Script</div>
        <div className="lsub">CONTENT STUDIO</div>
        {activeName&&<div style={{fontSize:11,color:"#22c55e",marginTop:8,fontWeight:600}}>📺 {activeName}</div>}
      </div>
      {nav.map(function(n){
        return <div key={n.id} className={"nitem" + (page===n.id?" active":"")}
          style={{opacity:n.req&&!configured?0.35:1,cursor:n.req&&!configured?"not-allowed":"pointer"}}
          onClick={function(){if(!n.req||configured)setPage(n.id);}}>
          <span>{n.icon}</span><span>{n.label}</span>
        </div>;
      })}
      <div className="nitem" onClick={function(){window.open("https://viraltrack-psi.vercel.app/","_blank");}}>
        <span>📊</span><span>Viraltrack</span>
      </div>
    </div>
  );
}
async function uploadToYouTube(videoBlob, meta, config) {
  const arrayBuffer = await videoBlob.arrayBuffer();
  const base64 = btoa(
    new Uint8Array(arrayBuffer).reduce(function (data, byte) {
      return data + String.fromCharCode(byte);
    }, "")
  );
  const res = await fetch("/api/youtube-upload", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      clientId: config.ytClientId,
      clientSecret: config.ytClientSecret,
      refreshToken: config.ytRefreshToken,
      title: meta.title,
      description: meta.description || "",
      videoBase64: base64,
      privacyStatus: meta.privacyStatus || "private",
    }),
  });
  const data = await res.json();
  if (!res.ok || data.error) throw new Error(data.error || "Error publicando en YouTube.");
  return data;
}
function ChannelForm(props) {
  const initial = props.initial || { name: "", niche: "", language: "es-latam", style: "reflexivo", tone: "", rhythm: "", palette: "", youtubeUrl: "", logo: "", ytRefreshToken: "" };
  const onSave = props.onSave, onCancel = props.onCancel, appConfig = props.appConfig || {};
  const [form, setForm] = useState(initial);
  const f = function (k) { return function (e) { setForm(function (p) { const np = Object.assign({}, p); np[k] = e.target.value; return np; }); }; };
  const ok = form.name && form.name.trim();
  const canConnectYT = appConfig.ytClientId && appConfig.ytClientSecret;
  // El redirect_uri que Google ve debe ser fijo y simple en los dos pasos del flujo
  // (autorizacion e intercambio de token) porque Google exige que coincida exactamente
  // con lo registrado en Google Cloud Console y con lo usado en el paso anterior.
  // clientId/clientSecret viajan aparte, en el parametro "state" (Google lo reenvia
  // intacto al callback sin exigir que este pre-registrado), nunca dentro del redirect_uri.
  const ytRedirectUri = window.location.origin + "/api/youtube-callback";
  const ytOAuthState = canConnectYT
    ? btoa(JSON.stringify({ clientId: appConfig.ytClientId, clientSecret: appConfig.ytClientSecret }))
    : "";
  const ytAuthUrl = canConnectYT ? (
    "/api/youtube-auth?clientId=" + encodeURIComponent(appConfig.ytClientId) +
    "&redirectUri=" + encodeURIComponent(ytRedirectUri) +
    "&state=" + encodeURIComponent(ytOAuthState)
  ) : "";

  const handleLogoUpload = function (evt) {
    const file = evt.target.files && evt.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function () {
      setForm(function (p) { return Object.assign({}, p, { logo: reader.result }); });
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="modal" onClick={onCancel}>
      <div className="modalbox" onClick={function (e) { e.stopPropagation(); }}>
        <div style={{ fontSize: 17, fontWeight: 700, marginBottom: 16 }}>{initial.id ? "✏️ Editar canal" : "➕ Nuevo canal"}</div>
        <div style={{ marginBottom: 14 }}>
          <label className="lbl">Nombre del canal</label>
          <input className="inp" placeholder="Viaje al Interior..." value={form.name} onChange={f("name")} />
        </div>
        <div style={{ marginBottom: 14 }}>
          <label className="lbl">Nicho principal</label>
          <input className="inp" placeholder="Espiritualidad, finanzas..." value={form.niche} onChange={f("niche")} />
        </div>
        <div className="g2" style={{ marginBottom: 14 }}>
          <div><label className="lbl">Idioma</label><select className="inp" value={form.language} onChange={f("language")}>{LANGUAGES.map(function (l) { return <option key={l.code} value={l.code}>{l.label}</option>; })}</select></div>
          <div><label className="lbl">Estilo</label><select className="inp" value={form.style} onChange={f("style")}>{STYLES.map(function (s) { return <option key={s.code} value={s.code}>{s.label}</option>; })}</select></div>
        </div>
        <div style={{ marginBottom: 14, padding: 12, border: "1px solid #222230", borderRadius: 10 }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 4 }}>🎨 Estilo fijo del canal (opcional)</div>
          <div style={{ fontSize: 11, color: "#7878a0", marginBottom: 10 }}>Se aplica a todos los guiones de este canal para que los videos se sientan de la misma marca.</div>
          <label className="lbl">Tono de narración</label>
          <input className="inp" style={{ marginBottom: 10 }} placeholder="Cálido y pausado, como un mentor cercano..." value={form.tone || ""} onChange={f("tone")} />
          <label className="lbl">Ritmo</label>
          <input className="inp" style={{ marginBottom: 10 }} placeholder="Frases cortas, cortes rápidos en el gancho, más lento al cierre..." value={form.rhythm || ""} onChange={f("rhythm")} />
          <label className="lbl">Paleta visual</label>
          <input className="inp" placeholder="Tonos cálidos dorados, luz de atardecer, naturaleza..." value={form.palette || ""} onChange={f("palette")} />
        </div>
        <div style={{ marginBottom: 14 }}>
          <label className="lbl">URL del canal de YouTube (opcional)</label>
          <input className="inp" placeholder="https://youtube.com/@..." value={form.youtubeUrl || ""} onChange={f("youtubeUrl")} />
        </div>
        <div style={{ marginBottom: 20 }}>
          <label className="lbl">Logo del canal (para watermark)</label>
          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
            <label className="btn bs" style={{ cursor: "pointer" }}>
              🖼️ Subir logo
              <input type="file" accept="image/*" style={{ display: "none" }} onChange={handleLogoUpload} />
            </label>
            {form.logo && <img src={form.logo} alt="logo" style={{ width: 40, height: 40, borderRadius: 8, objectFit: "cover" }} />}
          </div>
        </div>
        <div style={{ marginBottom: 20 }}>
          <label className="lbl">Conexión con YouTube (para publicar)</label>
          {!canConnectYT && <div className="alert ainf" style={{ fontSize: 12 }}>Primero configura el Client ID y Client Secret de YouTube en Configuración general.</div>}
          {canConnectYT && <div>
            <a className="btn bs" href={ytAuthUrl} target="_blank" rel="noreferrer" style={{ textDecoration: "none", display: "inline-flex", marginBottom: 10 }}>🔗 Conectar este canal con YouTube</a>
            <div style={{ fontSize: 11, color: "#7878a0", marginBottom: 8 }}>Después de autorizar, Google te muestra un código — pégalo aquí abajo.</div>
            <input className="inp" placeholder="Pega aquí el Refresh Token" value={form.ytRefreshToken || ""} onChange={f("ytRefreshToken")} />
            {form.ytRefreshToken && <div style={{ fontSize: 11, color: "#22c55e", marginTop: 6 }}>✓ Canal conectado con YouTube</div>}
          </div>}
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button className="btn bs" style={{ flex: 1, justifyContent: "center" }} onClick={onCancel}>Cancelar</button>
          <button className="btn bp" style={{ flex: 1, justifyContent: "center" }} onClick={function () { if (ok) onSave(form); }} disabled={!ok}>Guardar</button>
        </div>
      </div>
    </div>
  );
}

function ConfigPage(props){
  const config = props.config, setConfig = props.setConfig;
  const [form,setForm]=useState(config||{youtubeKey:"",pexelsKey:"",pixabayKey:"",anthropicKey:"",elevenlabsKey:"",elevenlabsKey2:"",geminiKey:"",cartesiaKey:"",freesoundKey:"",ytClientId:"",ytClientSecret:""});
  const [saved,setSaved]=useState(false);
  const [channels,setChannels]=useState(loadChannels());
  const [activeId,setActiveId]=useState(loadActiveChannelId());
  const [editingChannel,setEditingChannel]=useState(null);
  const [showForm,setShowForm]=useState(false);
  const [cacheCount,setCacheCount]=useState(null);
  useEffect(function(){audioCacheCount().then(setCacheCount);},[]);

  useEffect(function(){
    if(channels.length===0&&config&&(config.channelName||config.niche)){
      const migrated=[{id:"ch_"+Date.now(),name:config.channelName||"Mi canal",niche:config.niche||"",language:config.language||"es-latam",style:config.style||"reflexivo",youtubeUrl:"",logo:""}];
      setChannels(migrated);
      saveChannels(migrated);
      setActiveId(migrated[0].id);
      saveActiveChannelId(migrated[0].id);
    }
  },[]);

  const save=function(){saveConfig(form);setConfig(form);setSaved(true);setTimeout(function(){setSaved(false);},2000);};
  const f=function(k){return function(e){setForm(function(p){const np=Object.assign({},p);np[k]=e.target.value;return np;});};};
  const ok=form.youtubeKey&&form.pexelsKey&&form.anthropicKey;

  const openNewChannel=function(){setEditingChannel(null);setShowForm(true);};
  const openEditChannel=function(ch){setEditingChannel(ch);setShowForm(true);};
  const closeForm=function(){setShowForm(false);setEditingChannel(null);};

  const saveChannel=function(data){
    let updated;
    if(data.id){
      updated=channels.map(function(c){return c.id===data.id?data:c;});
    }else{
      const withId=Object.assign({},data,{id:"ch_"+Date.now()});
      updated=channels.concat([withId]);
      if(channels.length===0){setActiveId(withId.id);saveActiveChannelId(withId.id);}
    }
    setChannels(updated);
    saveChannels(updated);
    closeForm();
  };

  const deleteChannel=function(id){
    const updated=channels.filter(function(c){return c.id!==id;});
    setChannels(updated);
    saveChannels(updated);
    if(activeId===id){
      const newActive=updated.length?updated[0].id:null;
      setActiveId(newActive);
      saveActiveChannelId(newActive);
    }
  };

  const activateChannel=function(id){
    setActiveId(id);
    saveActiveChannelId(id);
  };

  return(
    <div>
      <div className="ptitle">Configuración</div>
      <div className="psub">Completa estos datos una sola vez.</div>
      {saved&&<div className="alert aok">✓ Guardado correctamente.</div>}
      <div className="card">
        <div style={{fontSize:15,fontWeight:700,marginBottom:14,paddingBottom:10,borderBottom:"1px solid #222230"}}>🔑 API Keys</div>
        {[{k:"youtubeKey",l:"YouTube Data API Key",p:"AIza..."},{k:"pexelsKey",l:"Pexels API Key",p:"Tu clave Pexels"},{k:"pixabayKey",l:"Pixabay API Key (opcional)",p:"Tu clave Pixabay"},{k:"anthropicKey",l:"Anthropic API Key",p:"sk-ant-..."},{k:"elevenlabsKey",l:"ElevenLabs API Key (opcional)",p:"Tu clave ElevenLabs"},{k:"elevenlabsKey2",l:"ElevenLabs API Key de respaldo (opcional, se usa si la principal falla)",p:"Segunda clave ElevenLabs"},{k:"geminiKey",l:"Google Gemini API Key (opcional, voz alternativa)",p:"AIza..."},{k:"cartesiaKey",l:"Cartesia API Key (opcional, voz alternativa)",p:"sk_car_..."},{k:"freesoundKey",l:"Freesound API Key (música de fondo)",p:"Tu clave Freesound"},{k:"ytClientId",l:"YouTube OAuth Client ID (para publicar)",p:"xxxx.apps.googleusercontent.com"},{k:"ytClientSecret",l:"YouTube OAuth Client Secret",p:"GOCSPX-..."}].map(function(item){
          return <div key={item.k} style={{marginBottom:14}}>
            <label className="lbl">{item.l}</label>
            <input className="inp" type="password" placeholder={item.p} value={form[item.k]||""} onChange={f(item.k)}/>
          </div>;
        })}
      </div>
      <button className="btn bp" onClick={save} disabled={!ok} style={{width:"100%",justifyContent:"center",padding:14,marginBottom:24}}>{ok?"💾 Guardar configuración":"Completa las API keys para continuar"}</button>
      <div className="card">
        <div style={{fontSize:15,fontWeight:700,marginBottom:8}}>♻️ Audio guardado (caché)</div>
        <div style={{fontSize:12,color:"#7878a0",marginBottom:10}}>Los audios generados se guardan en este dispositivo. Si vuelves a generar una escena con el mismo texto y la misma voz, se reutiliza sin gastar créditos. Audios guardados: {cacheCount===null?"...":cacheCount}</div>
        <button className="btn bs" style={{fontSize:12,padding:"6px 14px"}} onClick={function(){audioCacheClear().then(function(){setCacheCount(0);});}}>🗑️ Vaciar caché de audio</button>
      </div>

      <div className="card">
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14,paddingBottom:10,borderBottom:"1px solid #222230"}}>
          <div style={{fontSize:15,fontWeight:700}}>📺 Canales</div>
          <button className="btn bp" style={{fontSize:12,padding:"6px 14px"}} onClick={openNewChannel}>➕ Agregar canal</button>
        </div>
        {channels.length===0&&<div style={{fontSize:13,color:"#7878a0",padding:"10px 0"}}>No tienes canales todavía. Agrega uno para empezar a generar contenido personalizado.</div>}
        {channels.map(function(ch){
          const isActive=ch.id===activeId;
          const langObj=LANGUAGES.find(function(l){return l.code===ch.language;});
          const styleObj=STYLES.find(function(s){return s.code===ch.style;});
          return(
            <div key={ch.id} className={"chcard"+(isActive?" chactive":"")}>
              {isActive&&<span className="chbadge">ACTIVO</span>}
              <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:4}}>
                {ch.logo&&<img src={ch.logo} alt="" style={{width:32,height:32,borderRadius:6,objectFit:"cover"}}/>}
                <div style={{fontSize:15,fontWeight:700}}>{ch.name}</div>
              </div>
              <div style={{fontSize:12,color:"#7878a0",marginBottom:8}}>{ch.niche||"Sin nicho definido"}</div>
              <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:12}}>
                <span className="tag ta">{langObj?langObj.label:ch.language}</span>
                <span className="tag tg">{styleObj?styleObj.label:ch.style}</span>
              </div>
              {ch.youtubeUrl&&<div style={{fontSize:12,color:"#6c3fff",marginBottom:12,wordBreak:"break-all"}}>🔗 {ch.youtubeUrl}</div>}
              <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                {!isActive&&<button className="btn bp" style={{fontSize:12,padding:"5px 12px"}} onClick={function(){activateChannel(ch.id);}}>✓ Usar este canal</button>}
                <button className="btn bs" style={{fontSize:12,padding:"5px 12px"}} onClick={function(){openEditChannel(ch);}}>✏️ Editar</button>
                <button className="btn bs" style={{fontSize:12,padding:"5px 12px",color:"#fca5a5"}} onClick={function(){deleteChannel(ch.id);}}>🗑️ Eliminar</button>
              </div>
            </div>
          );
        })}
      </div>

      {showForm&&<ChannelForm initial={editingChannel} onSave={saveChannel} onCancel={closeForm} appConfig={form}/>}
    </div>
  );
}
function ResearchPage(props){
  const config = props.config;
  const [query,setQuery]=useState("");
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState("");
  const [videos,setVideos]=useState([]);
  const [filters,setFilters]=useState({duration:"long",language:"en",maxSubs:100000});
  const [aiKw,setAiKw]=useState([]);
  const [loadKw,setLoadKw]=useState(false);
  const defKw=["spiritual awakening","personal growth","mindfulness meditation","law of attraction","stoicism","self discipline","inner peace","healing prayer","faith and anxiety","consciousness"];
  const genKw=async function(){
    setLoadKw(true);
    try{
      const p="Genera 8 keywords en ingles para buscar videos virales de YouTube en el nicho de "+JSON.stringify(config.niche||"desarrollo personal")+". Canales faceless, videos largos. Responde SOLO con JSON array de strings.";
      const t=await callClaude(p,config);
      setAiKw(JSON.parse(t.replace(/```json|```/g,"").trim()));
    }catch(err){setAiKw(defKw.slice(0,8));}
    setLoadKw(false);
  };
  const search=async function(kw){
    const q=kw||query;if(!q.trim())return;
    setLoading(true);setError("");setVideos([]);
    try{
      const items=await searchYouTube(q,config,{duration:filters.duration,language:filters.language});
      if(!items.length){setError("No se encontraron videos.");setLoading(false);return;}
      const ids=items.map(function(i){return i.id?i.id.videoId:null;}).filter(Boolean);
      const chIds=Array.from(new Set(items.map(function(i){return i.snippet?i.snippet.channelId:null;}).filter(Boolean)));
      const results=await Promise.all([getVideoStats(ids,config),getChannelStats(chIds,config)]);
      const stats=results[0],channels=results[1];
      const chMap={};
      channels.forEach(function(c){chMap[c.id]=parseInt((c.statistics&&c.statistics.subscriberCount)||0);});
      const enriched=stats.map(function(v){
        const subs=chMap[v.snippet?v.snippet.channelId:null]||0;
        const views=parseInt((v.statistics&&v.statistics.viewCount)||0);
        const dur=parseDuration(v.contentDetails?v.contentDetails.duration:null);
        const copy=Object.assign({},v);
        copy.subs=subs;copy.views=views;copy.dur=dur;copy.score=outlierScore(views,subs);
        return copy;
      }).filter(function(v){return !filters.maxSubs||v.subs<=parseInt(filters.maxSubs);}).sort(function(a,b){return b.score-a.score;});
      setVideos(enriched);
    }catch(e){setError(e.message);}
    setLoading(false);
  };
  return(
    <div>
      <div className="ptitle">🔍 Investigar Nichos</div>
      <div className="psub">Encuentra videos outliers con alto potencial viral.</div>
      <div className="card">
        <div className="frow">
          <div className="fi" style={{flex:2}}><label className="lbl">Búsqueda</label><input className="inp" placeholder="spiritual awakening..." value={query} onChange={function(e){setQuery(e.target.value);}} onKeyDown={function(e){if(e.key==="Enter")search();}}/></div>
          <div className="fi"><label className="lbl">Duración</label><select className="inp" value={filters.duration} onChange={function(e){setFilters(function(p){return Object.assign({},p,{duration:e.target.value});});}}><option value="any">Todos</option><option value="short">Shorts</option><option value="medium">Medianos</option><option value="long">Largos</option></select></div>
          <div className="fi"><label className="lbl">Idioma</label><select className="inp" value={filters.language} onChange={function(e){setFilters(function(p){return Object.assign({},p,{language:e.target.value});});}}><option value="en">Inglés</option><option value="es">Español</option></select></div>
          <div className="fi"><label className="lbl">Máx subs</label><input className="inp" type="number" value={filters.maxSubs} onChange={function(e){setFilters(function(p){return Object.assign({},p,{maxSubs:e.target.value});});}}/></div>
          <button className="btn bp" onClick={function(){search();}} disabled={loading||!query.trim()}>{loading?"⏳":"Buscar"}</button>
        </div>
        <div style={{borderTop:"1px solid #222230",paddingTop:14}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
            <span className="lbl" style={{marginBottom:0}}>Keywords IA</span>
            <button className="btn bs" style={{fontSize:12,padding:"5px 12px"}} onClick={genKw} disabled={loadKw}>{loadKw?"Generando...":"✨ Generar"}</button>
          </div>
          <div className="kwr">{(aiKw.length?aiKw:defKw).map(function(kw){return <span key={kw} className={"kw"+(query===kw?" sel":"")} onClick={function(){setQuery(kw);search(kw);}}>{kw}</span>;})}</div>
        </div>
      </div>
      {error&&<div className="alert aerr">⚠️ {error}</div>}
      {loading&&<div className="loader"><div className="spin"/><span>Buscando joyas virales...</span></div>}
      {videos.length>0&&<div>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
          <span style={{fontSize:13,color:"#7878a0"}}>{videos.length} videos encontrados</span>
          <span className="tag tg">🔥 Top outliers primero</span>
        </div>
        <div className="g3">{videos.map(function(v){
          const thumb=v.snippet&&v.snippet.thumbnails&&v.snippet.thumbnails.medium?v.snippet.thumbnails.medium.url:null;
          const score=parseFloat(v.score);
          return(
            <div key={v.id} className="vc">
              <div className="vt" onClick={function(){window.open("https://youtube.com/watch?v="+v.id,"_blank");}}>{thumb&&<img src={thumb} alt=""/>}<span className="vd">{formatDuration(v.dur)}</span>{score>5&&<span className="ob">🔥 {score}x</span>}</div>
              <div className="vi">
                <div className="vtit">{v.snippet?v.snippet.title:""}</div>
                <div style={{fontSize:11,color:"#7878a0",marginBottom:8}}>{v.snippet?v.snippet.channelTitle:""} · {formatNumber(v.subs)} subs</div>
                <div className="srow">
                  <div><div style={{fontSize:18,fontWeight:700}}>{formatNumber(v.views)}</div><div style={{fontSize:11,color:"#7878a0"}}>vistas</div></div>
                  <div><div style={{fontSize:18,fontWeight:700,color:score>10?"#f0b429":"#6c3fff"}}>{score}x</div><div style={{fontSize:11,color:"#7878a0"}}>outlier</div></div>
                </div>
                <div style={{display:"flex",gap:6,marginTop:8}}>
                  <button className="btn bs" style={{fontSize:11,padding:"4px 10px",flex:1}} onClick={function(){window.open("https://youtube.com/watch?v="+v.id,"_blank");}}>▶ Ver</button>
                  <button className="btn bp" style={{fontSize:11,padding:"4px 10px",flex:2}} onClick={function(){navigator.clipboard.writeText("https://youtube.com/watch?v="+v.id);alert("URL copiada — pégala en Analizar Video");}}>🎯 Copiar URL</button>
                </div>
              </div>
            </div>
          );
        })}</div>
      </div>}
    </div>
  );
}
function AnalyzerPage(props){
  const config = props.config;
  const [url,setUrl]=useState("");
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState("");
  const [result,setResult]=useState(null);
  const [lang,setLang]=useState(config.language);
  const analyze=async function(){
    const m=url.match(/(?:v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
    if(!m){setError("URL inválida.");return;}
    setLoading(true);setError("");setResult(null);
    try{
      const stats=await getVideoStats([m[1]],config);
      const v=stats[0];if(!v)throw new Error("Video no encontrado.");
      const langObj=LANGUAGES.find(function(l){return l.code===lang;});
      const langLabel=langObj?langObj.label:"español";
      const styleObj=STYLES.find(function(s){return s.code===config.style;});
      const styleLabel=styleObj?styleObj.label:"reflexivo";
      const desc=(v.snippet&&v.snippet.description)?v.snippet.description.slice(0,400):"";
      const prompt="Analiza este video viral y genera 3 ideas adaptadas.\nVIDEO: "+JSON.stringify(v.snippet?v.snippet.title:"")+"\nDESCRIPCION: "+desc+"\n\nResponde SOLO en JSON valido:\n{\"estructura\":{\"hook\":\"texto\",\"desarrollo\":\"texto\",\"cierre\":\"texto\"},\"ideas\":[{\"titulo\":\"texto\",\"hook\":\"texto\",\"estructura\":\"texto\",\"miniatura\":\"texto\",\"palabrasClave\":[\"kw1\",\"kw2\"]}]}\n\n3 ideas en "+langLabel+", estilo "+styleLabel+", canal faceless. Solo JSON sin markdown.";
      const text=await callClaude(prompt,config);
            const parsed=parseAIJson(text);
      setResult({video:v,parsed:parsed,views:formatNumber(parseInt((v.statistics&&v.statistics.viewCount)||0)),dur:formatDuration(parseDuration(v.contentDetails?v.contentDetails.duration:null))});
    }catch(e){setError(e.message);}
    setLoading(false);
  };
  return(
    <div>
      <div className="ptitle">🎯 Analizar Video</div>
      <div className="psub">Pega la URL de un video outlier y obtén su estructura + 3 ideas.</div>
      <div className="card">
        <div className="frow">
          <div className="fi" style={{flex:3}}><label className="lbl">URL del video</label><input className="inp" placeholder="https://youtube.com/watch?v=..." value={url} onChange={function(e){setUrl(e.target.value);}}/></div>
          <div className="fi"><label className="lbl">Idioma salida</label><select className="inp" value={lang} onChange={function(e){setLang(e.target.value);}}>{LANGUAGES.map(function(l){return <option key={l.code} value={l.code}>{l.label}</option>;})}</select></div>
          <button className="btn bp" onClick={analyze} disabled={loading||!url.trim()}>{loading?"⏳":"Analizar"}</button>
        </div>
      </div>
      {error&&<div className="alert aerr">⚠️ {error}</div>}
      {loading&&<div className="loader"><div className="spin"/><span>Analizando estructura...</span></div>}
      {result&&<div>
        <div className="card">
          <div style={{fontSize:16,fontWeight:700,marginBottom:6}}>{result.video.snippet?result.video.snippet.title:""}</div>
          <div style={{fontSize:12,color:"#7878a0",marginBottom:14}}>{result.video.snippet?result.video.snippet.channelTitle:""} · {result.views} vistas · {result.dur}</div>
          {Object.keys(result.parsed.estructura).map(function(k){
            return <div key={k} style={{marginBottom:10}}><span className="tag ta" style={{marginBottom:5,display:"inline-block"}}>{k.toUpperCase()}</span><div style={{fontSize:13,marginTop:4,lineHeight:1.6}}>{result.parsed.estructura[k]}</div></div>;
          })}
        </div>
        <div style={{fontSize:17,fontWeight:700,margin:"20px 0 14px"}}>3 Ideas generadas</div>
        {result.parsed.ideas.map(function(idea,i){
          return <div key={i} className="card">
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:12}}><div style={{fontSize:15,fontWeight:700}}>{idea.titulo}</div><span className="tag tg">Idea {i+1}</span></div>
            <div style={{marginBottom:8}}><span className="lbl">Hook</span><div style={{fontSize:13,marginTop:4}}>{idea.hook}</div></div>
            <div style={{marginBottom:8}}><span className="lbl">Estructura</span><div style={{fontSize:13,marginTop:4}}>{idea.estructura}</div></div>
            <div style={{marginBottom:8}}><span className="lbl">Miniatura</span><div style={{fontSize:13,marginTop:4}}>{idea.miniatura}</div></div>
            <div className="kwr">{idea.palabrasClave&&idea.palabrasClave.map(function(kw){return <span key={kw} className="tag ta">{kw}</span>;})}</div>
          </div>;
        })}
      </div>}
    </div>
  );
}
const SHORTS_HISTORY_KEY="viralscript_shorts_history";
function loadShortsHistory(){
  try{const raw=localStorage.getItem(SHORTS_HISTORY_KEY);return raw?JSON.parse(raw):[];}catch(e){return [];}
}
function saveToShortsHistory(script){
  try{
    const list=loadShortsHistory();
    list.unshift({id:Date.now(),titulo:script.titulo,fecha:new Date().toISOString(),script:script});
    const trimmed=list.slice(0,15);
    localStorage.setItem(SHORTS_HISTORY_KEY,JSON.stringify(trimmed));
  }catch(e){}
}
function deleteFromShortsHistory(id){
  try{
    const list=loadShortsHistory().filter(function(h){return h.id!==id;});
    localStorage.setItem(SHORTS_HISTORY_KEY,JSON.stringify(list));
    return list;
  }catch(e){return [];}
}

function ShortsPage(props){
  const config = props.config;
  const [mode,setMode]=useState("ai");
  const [topic,setTopic]=useState("");
  const [lang,setLang]=useState(config.language);
  const [style,setStyle]=useState(config.style);
  const [characterStyle,setCharacterStyle]=useState("");
  const [loading,setLoading]=useState(false);
  const [loadingStep,setLoadingStep]=useState("");
  const [error,setError]=useState("");
  const [script,setScript]=useState(function(){
    const h=loadShortsHistory();
    return h.length?h[0].script:null;
  });
  const [restoredFromHistory,setRestoredFromHistory]=useState(function(){
    const h=loadShortsHistory();
    return h.length>0;
  });
  const [showHistory,setShowHistory]=useState(false);
  const [history,setHistory]=useState(function(){return loadShortsHistory();});
  const [clips,setClips]=useState({});
  const [loadClips,setLoadClips]=useState({});
  const [ownScript,setOwnScript]=useState("");
  const [ownAudioName,setOwnAudioName]=useState("");
  const [ownAudioUrl,setOwnAudioUrl]=useState("");
  const [voiceProvider,setVoiceProvider]=useState(defaultProvider(config));
  const [previewLoading,setPreviewLoading]=useState(false);
  const [previewError,setPreviewError]=useState("");
  const [voices,setVoices]=useState([]);
  const [voiceId,setVoiceId]=useState("");
  const [loadVoices,setLoadVoices]=useState(false);
  const [voiceError,setVoiceError]=useState("");
  const [genAudio,setGenAudio]=useState({});
  const [termKind,setTermKind]=useState({});
  const [discloseAI,setDiscloseAI]=useState(true);
  const [structWarning,setStructWarning]=useState("");
  const [paletteNote,setPaletteNote]=useState("");
  const [genAudioLoading,setGenAudioLoading]=useState({});
  const [selectedClip,setSelectedClip]=useState({});
  const [videoSource,setVideoSource]=useState({});
  const [customClip,setCustomClip]=useState({});
  const [assembling,setAssembling]=useState(false);
  const [assembleProgress,setAssembleProgress]=useState("");
  const [assembledUrl,setAssembledUrl]=useState("");
  const [assembleError,setAssembleError]=useState("");
  const [showAssembleWarning,setShowAssembleWarning]=useState(false);
  const [musicResults,setMusicResults]=useState([]);
  const [selectedMusic,setSelectedMusic]=useState(null);
  const [loadingMusic,setLoadingMusic]=useState(false);
  const [publishing,setPublishing]=useState(false);
  const [publishResult,setPublishResult]=useState(null);
  const [publishError,setPublishError]=useState("");
  const [queue,setQueue]=useState(function(){return loadQueue();});
  const [queueLoading,setQueueLoading]=useState(false);
  const [queueError,setQueueError]=useState("");

  useEffect(function(){
    setVoiceError("");
    setVoices([]);
    setVoiceId("");
    const prov=VOICE_PROVIDERS.find(function(pr){return pr.code===voiceProvider;});
    if(prov&&config[prov.key]){
      setLoadVoices(true);
      loadVoicesFor(voiceProvider,config).then(function(v){
        setVoices(v);
        if(v.length)setVoiceId(v[0].voice_id);
        setLoadVoices(false);
      }).catch(function(){setVoiceError("No se pudo conectar con "+prov.label+". Verifica tu API key.");setLoadVoices(false);});
    }
  },[config.elevenlabsKey,config.geminiKey,config.cartesiaKey,config.language,voiceProvider]);

  const publishVideo=async function(){
    setPublishing(true);setPublishError("");setPublishResult(null);
    try{
      const blob=await (await fetch(assembledUrl)).blob();
      const result=await uploadToYouTube(blob,{
        title:script.titulo,
        description:script.escenas?script.escenas.map(function(e){return e.guion;}).join(" "):"",
        privacyStatus:"private",
      },config);
      setPublishResult(result);
    }catch(err){setPublishError(err.message);}
    setPublishing(false);
  };

  const previewGeminiVoice=async function(){
    setPreviewLoading(true);setPreviewError("");
    try{
      const audioUrl=await speak(voiceProvider,"Hola, así suena mi voz.",voiceId,config);
      const audio=new Audio(audioUrl);
      audio.play();
    }catch(err){setPreviewError(err.message);}
    setPreviewLoading(false);
  };

  const generateAudioForScene=async function(e){
    setGenAudioLoading(function(p){const np=Object.assign({},p);np[e.numero]=true;return np;});
    try{
      const cleanGuion=stripVoiceMarkers(e.guion);const audioUrl=await speak(voiceProvider,cleanGuion,voiceId,config);
      setGenAudio(function(p){const np=Object.assign({},p);np[e.numero]=audioUrl;return np;});
    }catch(err){setError(err.message);}
    setGenAudioLoading(function(p){const np=Object.assign({},p);np[e.numero]=false;return np;});
  };

  const generateAudioFull=async function(){
    if(!script||!script.escenas)return;
    for(const e of script.escenas){
      await generateAudioForScene(e);
    }
  };

  const searchMusicForScript=async function(){
    if(!script||!config.freesoundKey)return;
    setLoadingMusic(true);
    try{
      const q=(script.palabras_clave&&script.palabras_clave[0])||script.titulo||"ambient";
      const results=await searchFreesoundMusic(q,config);
      setMusicResults(results);
    }catch(err){}
    setLoadingMusic(false);
  };

  const generate=async function(){
    if(!topic.trim())return;
    setLoading(true);setError("");setScript(null);setClips({});setRestoredFromHistory(false);setStructWarning("");
    acquireWakeLock();
    try{
      const lObj=LANGUAGES.find(function(l){return l.code===lang;});
      const lL=lObj?lObj.label:"español neutro";
      const sObj=STYLES.find(function(s){return s.code===style;});
      const sL=sObj?sObj.label:"reflexivo";
      const recentHooks=history.slice(0,3).map(function(h){return h.script&&h.script.escenas&&h.script.escenas[0]?h.script.escenas[0].guion:"";}).filter(function(t){return t;});
      const varLine=recentHooks.length?("\nIMPORTANTE - VARIACION: tus ultimos guiones de este canal empezaron asi (NO repitas la misma estructura de apertura, palabras ni angulo): "+recentHooks.map(function(t){return JSON.stringify(t.slice(0,140));}).join(" | ")+". El gancho de este nuevo guion debe sentirse claramente distinto."):"";

      setLoadingStep("Paso 1/4 — Generando ideas con gancho...");
      const p1="Genera 3 ideas de YouTube Short sobre "+JSON.stringify(topic)+" en "+lL+", estilo "+sL+". No quiero ideas genericas ni titulos tipo 'como mejorar en'. Cada idea debe basarse en un problema real y especifico que alguien ya esta viviendo, algo que genere identificacion inmediata tipo 'esto me pasa'. Responde SOLO JSON: {\"ideas\":[\"idea1\",\"idea2\",\"idea3\"]}. Sin markdown.";
      const r1=await callClaude(p1,config);
      const ideas=JSON.parse(r1.replace(/```json|```/g,"").trim());
      const ideaElegida=ideas.ideas&&ideas.ideas[0]?ideas.ideas[0]:topic;

      setLoadingStep("Paso 2/4 — Construyendo estructura...");
      const p2="Voy a hacer este YouTube Short: "+JSON.stringify(ideaElegida)+". Dame SOLO la estructura del guion, sin escribir el contenido todavia. Debe ser un proceso que lleve a un resultado claro, maximo 3 partes ademas del hook (formato short de 55-60 segundos). Cada parte debe existir por una razon. Responde SOLO JSON: {\"estructura\":[\"parte1 descripcion breve\",\"parte2 descripcion breve\",\"parte3 descripcion breve\"]}. Sin markdown.";
      const r2=await callClaude(p2,config);
      const estructura=JSON.parse(r2.replace(/```json|```/g,"").trim());

      setLoadingStep("Paso 3/4 — Creando el hook...");
      const p3="Escribe un hook de 3 segundos para este short: "+JSON.stringify(ideaElegida)+" con esta estructura: "+JSON.stringify(estructura.estructura)+". Idioma "+lL+", estilo "+sL+". No empieces explicando, no suene a tutorial. Genera curiosidad o tension: describe una situacion real, rompe una creencia, o contradice lo que la persona piensa. No resuelvas el problema todavia. Responde SOLO JSON: {\"hook\":\"texto del hook\"}. Sin markdown.";
      const r3=await callClaude(p3,config);
      const hookData=JSON.parse(r3.replace(/```json|```/g,"").trim());

      setLoadingStep("Paso 4/4 — Desarrollando guion completo y cierre...");
      const charLine=characterStyle.trim()?("\\nIMPORTANTE: en TODOS los prompt_video, incluye siempre este mismo personaje o estilo visual para mantener consistencia entre escenas: \""+characterStyle.trim()+"\". Integralo naturalmente en la descripcion del sujeto de cada escena."):"";
      const p4="Desarrolla el guion completo de este YouTube Short.\nIDEA: "+JSON.stringify(ideaElegida)+"\nESTRUCTURA: "+JSON.stringify(estructura.estructura)+"\nHOOK: "+JSON.stringify(hookData.hook)+"\nIdioma: "+lL+", Estilo: "+sL+". Sin emojis, sin marca personal, lenguaje simple para voz IA, sin listas dentro del guion hablado.\nEl desarrollo debe explicar una idea clara con un ejemplo que se entienda rapido. El final NO debe ser un resumen generico: recuerda el problema inicial desde una nueva perspectiva y cierra con una idea clara que se quede en la cabeza, conectando con el inicio.\nPara prompt_video escribe un prompt cinematografico en ingles en un solo parrafo fluido que cubra en este orden: tipo de plano (close-up, wide shot, etc), sujeto y su apariencia, entorno y ambiente, mood/energia de la escena, accion especifica que hace el sujeto, iluminacion, y estilo visual (cinematic, found-footage, etc). No uses corchetes ni etiquetas, solo texto natural que fluya como una sola descripcion lista para pegar en Veo3, Runway o Sora."+charLine+buildChannelStyleLine(config)+"\nPara busqueda_clip genera 3 variantes en ingles para buscar stock footage: 'literal' (accion+contexto+movimiento especifico, ej 'person writing notebook slow motion office desk'), 'metaforica' (una imagen simbolica que represente la idea sin mostrarla literalmente, ej para 'decision dificil' usar 'crossroads path fog slow motion'), y 'textura' (un plano de ambiente/textura abstracta que sirva de conector visual, ej 'water ripples close up slow motion'). IMPORTANTE: mantene coherencia de paleta de color y atmosfera visual entre las 3 escenas del short (evita saltos bruscos de tono, por ejemplo de calido a frio sin razon), como si fueran parte del mismo cortometraje."+varLine+"\nResponde SOLO JSON:\n{\"titulo\":\"texto\",\"duracion_total\":\"55-60 segundos\",\"escenas\":[{\"numero\":1,\"tipo\":\"HOOK\",\"duracion\":\"3 segundos\",\"guion\":\"texto\",\"prompt_video\":\"prompt ingles\",\"busqueda_clip\":{\"literal\":\"keyword ingles\",\"metaforica\":\"keyword ingles\",\"textura\":\"keyword ingles\"}},{\"numero\":2,\"tipo\":\"DESARROLLO\",\"duracion\":\"45 segundos\",\"guion\":\"texto\",\"prompt_video\":\"prompt ingles\",\"busqueda_clip\":{\"literal\":\"keyword ingles\",\"metaforica\":\"keyword ingles\",\"textura\":\"keyword ingles\"}},{\"numero\":3,\"tipo\":\"CIERRE\",\"duracion\":\"10 segundos\",\"guion\":\"texto\",\"prompt_video\":\"prompt ingles\",\"busqueda_clip\":{\"literal\":\"keyword ingles\",\"metaforica\":\"keyword ingles\",\"textura\":\"keyword ingles\"}}]}\nSolo JSON sin markdown.";
      const text=await callClaude(p4,config);
            const finalScript=parseAIJson(text);
      setScript(finalScript);
      const openingNew=finalScript.escenas&&finalScript.escenas[0]?finalScript.escenas[0].guion:"";
      let maxSim=0;
      recentHooks.forEach(function(t){const s=textSimilarity(openingNew,t);if(s>maxSim)maxSim=s;});
      setStructWarning(maxSim>0.45?("⚠️ El gancho de este guion se parece bastante a uno de tus ultimos videos ("+Math.round(maxSim*100)+"% de palabras clave en comun). Considera regenerar para un angulo mas distinto."):"");
      saveToShortsHistory(finalScript);
      setHistory(loadShortsHistory());
      autoFetchAllClips(finalScript);
    }catch(e){setError(e.message||"Error generando. Verifica tu Anthropic API key y saldo.");}
    setLoading(false);setLoadingStep("");
    releaseWakeLock();
  };

  const useOwnScript=async function(){
    if(!ownScript.trim())return;
    setLoading(true);setError("");setScript(null);setClips({});setRestoredFromHistory(false);
    acquireWakeLock();
    setLoadingStep("Analizando tu guion y dividiendo en escenas...");
    try{
      const prompt="Toma este guion de YouTube Short escrito por el usuario y divídelo en escenas (HOOK, DESARROLLO, CIERRE) sin modificar el texto original, solo organizándolo. Para prompt_video escribe un prompt cinematografico en ingles en un solo parrafo fluido que cubra en este orden: tipo de plano, sujeto y su apariencia, entorno y ambiente, mood/energia, accion especifica, iluminacion, y estilo visual. No uses corchetes ni etiquetas, solo texto natural listo para pegar en Veo3, Runway o Sora. Para busqueda_clip genera 3 variantes en ingles para buscar stock footage: 'literal' (accion+contexto+movimiento especifico), 'metaforica' (imagen simbolica que represente la idea sin mostrarla literalmente), y 'textura' (plano de ambiente/textura abstracta que sirva de conector visual). Mantene coherencia de paleta de color y atmosfera entre escenas consecutivas.\nGUION DEL USUARIO:\n"+ownScript+"\n\nResponde SOLO JSON:\n{\"titulo\":\"titulo corto basado en el guion\",\"duracion_total\":\"estimado\",\"escenas\":[{\"numero\":1,\"tipo\":\"HOOK\",\"duracion\":\"estimado\",\"guion\":\"texto exacto del usuario para esta parte\",\"prompt_video\":\"prompt ingles\",\"busqueda_clip\":{\"literal\":\"keyword ingles\",\"metaforica\":\"keyword ingles\",\"textura\":\"keyword ingles\"}}]}\nDivide en 2 a 4 escenas segun el contenido. Solo JSON sin markdown.";
      const text=await callClaude(prompt,config);
            const finalScript=parseAIJson(text);
      setScript(finalScript);
      saveToShortsHistory(finalScript);
      setHistory(loadShortsHistory());
      autoFetchAllClips(finalScript);
    }catch(e){setError(e.message||"Error procesando tu guion. Verifica tu Anthropic API key.");}
    setLoading(false);setLoadingStep("");
    releaseWakeLock();
  };

  const handleQueueUpload=async function(evt){
    const file=evt.target.files&&evt.target.files[0];
    if(!file)return;
    setQueueError("");setQueueLoading(true);
    try{
      const items=await parseScriptExcel(file);
      if(!items.length){setQueueError("No se encontraron guiones en el archivo. Verifica que tenga una columna 'Guion'.");setQueueLoading(false);return;}
      const updated=queue.concat(items);
      setQueue(updated);
      saveQueue(updated);
    }catch(err){setQueueError(err.message);}
    setQueueLoading(false);
    evt.target.value="";
  };

  const useQueueItem=function(item){
    setOwnScript(item.guion);
    if(item.idioma){
      const match=LANGUAGES.find(function(l){return l.label.toLowerCase()===item.idioma.toLowerCase()||l.code===item.idioma;});
      if(match)setLang(match.code);
    }
    const updated=queue.map(function(q){return q.id===item.id?Object.assign({},q,{estado:"Usado"}):q;});
    setQueue(updated);
    saveQueue(updated);
  };

  const deleteQueueItem=function(id){
    const updated=queue.filter(function(q){return q.id!==id;});
    setQueue(updated);
    saveQueue(updated);
  };

  const autoFetchAllClips=async function(scr){
    if(!scr||!scr.escenas)return;
    for(const e of scr.escenas){
      fetchClips(e);
    }
  };

  useEffect(function(){
    if(script)autoFetchAllClips(script);
  },[]);

  const fetchClips=async function(e,termKindArg){
    const tk=termKindArg||termKind[e.numero]||"literal";
    const q=getBusquedaTerm(e,tk);
    setTermKind(function(p){const np=Object.assign({},p);np[e.numero]=tk;return np;});
    setLoadClips(function(p){const np=Object.assign({},p);np[e.numero]=true;return np;});
    try{
      const results=await Promise.all([searchPexels(q,config),config.pixabayKey?searchPixabay(q,config):Promise.resolve([])]);
      setClips(function(p){const np=Object.assign({},p);np[e.numero]={px:results[0],pb:results[1]};return np;});
    }catch(err){}
    setLoadClips(function(p){const np=Object.assign({},p);np[e.numero]=false;return np;});
  };

  const handleAudioUpload=function(ev){
    const file=ev.target.files&&ev.target.files[0];
    if(!file)return;
    setOwnAudioName(file.name);
    const url=URL.createObjectURL(file);
    setOwnAudioUrl(url);
  };

  const getClipKey=function(src,idx){return src+"_"+idx;};

  const handleCustomClipUpload=function(evt,numero){
    const file=evt.target.files[0];
    if(!file)return;
    const url=URL.createObjectURL(file);
    setCustomClip(function(p){const np=Object.assign({},p);np[numero]={url:url,name:file.name};return np;});
  };

  const getClipDuration=function(numero,src,idx){
    const cl=clips[numero];
    if(!cl)return 0;
    if(src==="px"&&cl.px&&cl.px[idx])return cl.px[idx].duration||8;
    if(src==="pb"&&cl.pb&&cl.pb[idx])return cl.pb[idx].duration||8;
    return 8;
  };

  const toggleClip=function(numero,src,idx){
    setSelectedClip(function(p){
      const np=Object.assign({},p);
      const current=np[numero]?np[numero].slice():[];
      const key=getClipKey(src,idx);
      const existingPos=current.findIndex(function(c){return c.key===key;});
      if(existingPos>=0){
        current.splice(existingPos,1);
      }else{
        current.push({key:key,src:src,idx:idx});
      }
      np[numero]=current;
      return np;
    });
  };

  const getSelectedOrder=function(numero,src,idx){
    const list=selectedClip[numero];
    if(!list)return 0;
    const key=getClipKey(src,idx);
    const pos=list.findIndex(function(c){return c.key===key;});
    return pos>=0?pos+1:0;
  };

  const getSceneNeededSeconds=function(e){
    const m=e.duracion&&e.duracion.match(/(\d+)/g);
    if(!m)return 8;
    const nums=m.map(Number);
    return nums.length>1?Math.max.apply(null,nums):nums[0];
  };

  const getSelectedSeconds=function(numero){
    const list=selectedClip[numero];
    if(!list||!list.length)return 0;
    let total=0;
    list.forEach(function(c){total+=getClipDuration(numero,c.src,c.idx);});
    return total;
  };

  const getFirstClipPoster=function(numero){
    const cl=clips[numero];
    if(!cl)return null;
    const list=selectedClip[numero];
    let src="px",idx=0;
    if(list&&list.length){src=list[0].src;idx=list[0].idx;}
    const v=src==="px"?(cl.px&&cl.px[idx]):(cl.pb&&cl.pb[idx]);
    if(!v)return null;
    if(src==="px")return v.image||null;
    return v.picture_id?("https://i.vimeocdn.com/video/"+v.picture_id+"_295x166.jpg"):null;
  };
  const pickClipUrls=function(numero){
    if(customClip[numero])return [customClip[numero].url];
    const list=selectedClip[numero];
    const cl=clips[numero];
    if(!cl)return [];
    if(list&&list.length){
      return list.map(function(c){
        if(c.src==="px"&&cl.px&&cl.px[c.idx])return cl.px[c.idx].video_files&&cl.px[c.idx].video_files[0]?cl.px[c.idx].video_files[0].link:null;
        if(c.src==="pb"&&cl.pb&&cl.pb[c.idx])return cl.pb[c.idx].videos&&cl.pb[c.idx].videos.small?cl.pb[c.idx].videos.small.url:null;
        return null;
      }).filter(Boolean);
    }
    if(cl.px&&cl.px[0])return [cl.px[0].video_files&&cl.px[0].video_files[0]?cl.px[0].video_files[0].link:null].filter(Boolean);
    if(cl.pb&&cl.pb[0])return [cl.pb[0].videos&&cl.pb[0].videos.small?cl.pb[0].videos.small.url:null].filter(Boolean);
    return [];
  };

  const [zipLoading,setZipLoading]=useState(false);

  const downloadSceneZip=async function(e){
    setZipLoading(true);
    try{
      const entries=[{text:e.guion,path:"guion.txt"}];
      const audioUrl=genAudio[e.numero];
      if(audioUrl)entries.push({url:audioUrl,path:"audio."+extFromUrl(audioUrl)});
      const clipUrls=pickClipUrls(e.numero);
      clipUrls.forEach(function(u,i){entries.push({url:u,path:"clip_"+(i+1)+"."+extFromUrl(u)});});
      await buildZip(entries,"escena_"+padNum(e.numero)+"_"+e.tipo+".zip");
    }catch(err){}
    setZipLoading(false);
  };

  const downloadAllZip=async function(){
    if(!script||!script.escenas)return;
    setZipLoading(true);
    try{
      const entries=[];
      if(discloseAI)entries.push({text:"RECORDATORIO DE DIVULGACION - YouTube\n\nEste video fue producido con voz generada por IA. Antes de publicar:\n1. En YouTube Studio, ve a Detalles del video - Mas opciones.\n2. Activa el interruptor Contenido alterado o sintetico.\n3. Marca la opcion correspondiente a voz o audio generado por IA.\n\nEsto no afecta la monetizacion ni el alcance del video, pero evita strikes de la plataforma por incumplimiento de politicas de divulgacion (Inauthentic Content Policy, 2026)."+(paletteNote?("\n\nPaleta / tono visual definido para este video: "+paletteNote):""),path:"recordatorio_divulgacion.txt"});
      const audioUrlsOrdenados=[];
      for(const e of script.escenas){
        const folder="escena_"+padNum(e.numero)+"_"+e.tipo+"/";
        entries.push({text:e.guion,path:folder+"guion.txt"});
        const audioUrl=genAudio[e.numero];
        if(audioUrl){entries.push({url:audioUrl,path:folder+"audio."+extFromUrl(audioUrl)});audioUrlsOrdenados.push(audioUrl);}
        const clipUrls=pickClipUrls(e.numero);
        clipUrls.forEach(function(u,i){entries.push({url:u,path:folder+"clip_"+(i+1)+"."+extFromUrl(u)});});
      }
      if(ownAudioUrl){
        entries.push({url:ownAudioUrl,path:"audio_completo."+extFromUrl(ownAudioUrl)});
      }else if(audioUrlsOrdenados.length>0){
        const wavBlob=await concatAudioToWav(audioUrlsOrdenados);
        if(wavBlob)entries.push({blob:wavBlob,path:"audio_completo.wav"});
      }
      await buildZip(entries,(script.titulo||"short")+".zip");
    }catch(err){}
    setZipLoading(false);
  };

  const runAssembly=async function(){
    setShowAssembleWarning(false);
    setAssembling(true);setAssembleError("");setAssembledUrl("");
    try{
      if(!script||!script.escenas)throw new Error("No hay guion generado.");
      const clipList=[];
      for(const e of script.escenas){
        const urls=pickClipUrls(e.numero);
        if(!urls.length)throw new Error("Falta un clip para la escena "+e.numero+". Selecciona al menos un clip primero.");
        urls.forEach(function(u){clipList.push({url:u});});
      }
      let audioSrc=ownAudioUrl||"";
      if(!audioSrc){
        const first=script.escenas[0];
        if(genAudio[first.numero])audioSrc=genAudio[first.numero];
      }
      const resultUrl=await assembleVideo(
        clipList,
        audioSrc,
        config.logo||null,
        selectedMusic?selectedMusic.previews["preview-hq-mp3"]:null,
        function(msg){setAssembleProgress(msg);}
      );
      setAssembledUrl(resultUrl);
    }catch(e){setAssembleError(e.message||"Error ensamblando el video.");}
    setAssembling(false);setAssembleProgress("");
  };

  const sc={HOOK:"#f0b429",DESARROLLO:"#6c3fff",CIERRE:"#22c55e"};

  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
        <div>
          <div className="ptitle">⚡ Generar Short</div>
          <div className="psub">Script completo con prompts y clips para cada escena.</div>
        </div>
        <button className="btn bs" style={{fontSize:12,padding:"6px 12px",whiteSpace:"nowrap"}} onClick={function(){setHistory(loadShortsHistory());setShowHistory(true);}}>🕒 Historial ({history.length})</button>
      </div>

      {showHistory&&<div className="modal" onClick={function(){setShowHistory(false);}}>
        <div className="modalbox" onClick={function(e){e.stopPropagation();}}>
          <div style={{fontSize:17,fontWeight:700,marginBottom:14}}>🕒 Historial de guiones</div>
          {history.length===0&&<div style={{fontSize:13,color:"#7878a0"}}>Todavía no generaste ningún guion.</div>}
          {history.map(function(h){
            const d=new Date(h.fecha);
            const fechaStr=d.toLocaleDateString()+" "+d.toLocaleTimeString().slice(0,5);
            return <div key={h.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 0",borderBottom:"1px solid #2a2a3e"}}>
              <div style={{flex:1,cursor:"pointer"}} onClick={function(){setScript(h.script);autoFetchAllClips(h.script);setShowHistory(false);}}>
                <div style={{fontSize:13,fontWeight:600}}>{h.titulo}</div>
                <div style={{fontSize:11,color:"#7878a0"}}>{fechaStr}</div>
              </div>
              <button onClick={function(){setHistory(deleteFromShortsHistory(h.id));}} style={{background:"transparent",border:"none",color:"#e05252",fontSize:16,cursor:"pointer",padding:"4px 8px"}}>🗑️</button>
            </div>;
          })}
          <button className="btn bs" style={{width:"100%",justifyContent:"center",marginTop:16}} onClick={function(){setShowHistory(false);}}>Cerrar</button>
        </div>
      </div>}

      <div className="tabs">
        <button className={"tab"+(mode==="ai"?" active":"")} onClick={function(){setMode("ai");}}>✨ Generar con IA</button>
        <button className={"tab"+(mode==="own"?" active":"")} onClick={function(){setMode("own");}}>📝 Ya tengo mi guion</button>
      </div>

      {mode==="ai"&&<div className="card">
        <div className="frow">
          <div className="fi" style={{flex:3}}><label className="lbl">Frase o Tema</label><input className="inp" placeholder="El silencio que transforma..." value={topic} onChange={function(e){setTopic(e.target.value);}} onKeyDown={function(e){if(e.key==="Enter")generate();}}/></div>
          <div className="fi"><label className="lbl">Idioma</label><select className="inp" value={lang} onChange={function(e){setLang(e.target.value);}}>{LANGUAGES.map(function(l){return <option key={l.code} value={l.code}>{l.label}</option>;})}</select></div>
          <div className="fi"><label className="lbl">Estilo</label><select className="inp" value={style} onChange={function(e){setStyle(e.target.value);}}>{STYLES.map(function(s){return <option key={s.code} value={s.code}>{s.label}</option>;})}</select></div>
          <button className="btn bg" onClick={generate} disabled={loading||!topic.trim()}>{loading?"⏳":"⚡ Generar"}</button>
        </div>
        <div style={{marginTop:12}}>
          <label className="lbl">Personaje / estilo visual para los clips de IA (opcional)</label>
          <input className="inp" placeholder="Ej: hombre adulto con barba y lentes, estilo selfie casero, luz calida" value={characterStyle} onChange={function(e){setCharacterStyle(e.target.value);}}/>
          <div style={{fontSize:11,color:"#7878a0",marginTop:4}}>Si lo completas, todos los prompts Veo3/Runway/Sora de este guion van a describir el mismo personaje o estilo para mantener consistencia visual entre escenas.</div>
        </div>
      </div>}

      {mode==="own"&&<div className="card">
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
          <span className="lbl" style={{marginBottom:0}}>📊 Cola de guiones (Excel)</span>
          <label className="btn bs" style={{cursor:"pointer",fontSize:12,padding:"5px 12px"}}>
            {queueLoading?"Leyendo...":"📤 Subir Excel"}
            <input type="file" accept=".xlsx,.xls" style={{display:"none"}} onChange={handleQueueUpload} disabled={queueLoading}/>
          </label>
        </div>
        <div style={{fontSize:11,color:"#7878a0",marginBottom:10}}>El archivo debe tener una columna "Guion" (y opcionalmente Canal, Idioma, Estilo).</div>
        {queueError&&<div className="alert aerr" style={{fontSize:12}}>⚠️ {queueError}</div>}
        {queue.filter(function(q){return q.estado==="Pendiente";}).length>0&&<div style={{marginBottom:14}}>
          {queue.filter(function(q){return q.estado==="Pendiente";}).map(function(q){
            return <div key={q.id} style={{display:"flex",alignItems:"center",gap:8,padding:"8px 0",borderBottom:"1px solid #222230"}}>
              <div style={{flex:1,fontSize:12,color:"#e8e8f0",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{q.guion}</div>
              <button className="btn bp" style={{fontSize:11,padding:"4px 10px",whiteSpace:"nowrap"}} onClick={function(){useQueueItem(q);}}>Usar</button>
              <button onClick={function(){deleteQueueItem(q.id);}} style={{background:"transparent",border:"none",color:"#e05252",fontSize:14,cursor:"pointer",padding:"2px 6px"}}>🗑️</button>
            </div>;
          })}
        </div>}
        {queue.length===0&&<div style={{fontSize:12,color:"#7878a0",marginBottom:10}}>Todavía no subiste ningún archivo.</div>}
        <div className="div"/>
        <label className="lbl">Pega tu guion completo</label>
        <textarea className="inp" style={{minHeight:160,resize:"vertical",fontFamily:"inherit",lineHeight:1.5}} placeholder="Pega aqui tu guion ya escrito..." value={ownScript} onChange={function(e){setOwnScript(e.target.value);}}/>
        <div style={{marginTop:14}}>
          <label className="lbl">Audio propio (opcional)</label>
          <div style={{display:"flex",gap:10,alignItems:"center",flexWrap:"wrap"}}>
            <label className="btn bs" style={{cursor:"pointer"}}>
              🎵 Subir audio
              <input type="file" accept="audio/*" style={{display:"none"}} onChange={handleAudioUpload}/>
            </label>
            {ownAudioName&&<span style={{fontSize:12,color:"#7878a0"}}>{ownAudioName}</span>}
          </div>
          {ownAudioUrl&&<audio controls src={ownAudioUrl} style={{width:"100%",marginTop:10}}/>}
        </div>
        <button className="btn bg" onClick={useOwnScript} disabled={loading||!ownScript.trim()} style={{marginTop:16}}>{loading?"⏳":"📋 Organizar en escenas"}</button>
      </div>}

      {error&&<div className="alert aerr">⚠️ {error}</div>}
      {loading&&<div><div className="loader"><div className="spin"/><span>{loadingStep||"Procesando..."}</span></div><div style={{fontSize:11,color:"#7878a0",marginTop:-6,marginBottom:10}}>📵 No bloquees la pantalla ni cambies de app mientras genera, puede cortar la conexion.</div></div>}

      {script&&<div>
        {restoredFromHistory&&<div className="alert ainf" style={{fontSize:12,marginBottom:10}}>🕒 Este es tu último guion generado, restaurado automáticamente. <span style={{textDecoration:"underline",cursor:"pointer"}} onClick={function(){setHistory(loadShortsHistory());setShowHistory(true);}}>Ver historial completo</span></div>}
        <div className="card" style={{borderColor:"#f0b429"}}>
          <div style={{fontSize:17,fontWeight:700}}>{script.titulo}</div>
          <div style={{fontSize:12,color:"#7878a0",marginTop:4}}>⏱ {script.duracion_total}</div>
          {ownAudioUrl&&<audio controls src={ownAudioUrl} style={{width:"100%",marginTop:10}}/>}
          <input className="inp" style={{marginTop:10,fontSize:12}} placeholder="🎨 Paleta / tono visual del video (ej: cálido, desaturado, luz natural) — checklist de referencia al elegir clips" value={paletteNote} onChange={function(ev){setPaletteNote(ev.target.value);}}/>
          <label style={{display:"flex",alignItems:"center",gap:8,marginTop:10,fontSize:12,color:"#a0a0c0",cursor:"pointer"}}>
            <input type="checkbox" checked={discloseAI} onChange={function(ev){setDiscloseAI(ev.target.checked);}}/>
            🏷️ Marcar como contenido alterado/sintetico en YouTube Studio antes de publicar
          </label>
          {discloseAI&&<div className="alert ainf" style={{fontSize:11,marginTop:8}}>Recordatorio: en YouTube Studio → Detalles del video → Mas opciones, activa "Contenido alterado o sintetico" (voz generada por IA). Esto no afecta la monetizacion ni el alcance, pero evita strikes por incumplimiento de divulgacion.</div>}
          {structWarning&&<div className="alert aerr" style={{fontSize:11,marginTop:8}}>{structWarning}</div>}
        </div>

        <div className="card">
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span className="lbl">Guion completo</span>
            <button className="btn bs" style={{fontSize:12,padding:"4px 10px"}} onClick={function(){const full=script.escenas?script.escenas.map(function(e){return "["+e.tipo+" — "+e.duracion+"]\n"+e.guion;}).join("\n\n─────────────────────\n\n"):"";navigator.clipboard.writeText(full);}}>📋 Copiar todo</button>
          </div>
          <div className="stxt" style={{marginTop:8,whiteSpace:"pre-wrap"}}>{script.escenas?script.escenas.map(function(e){return "["+e.tipo+" — "+e.duracion+"]\n"+e.guion;}).join("\n\n─────────────────────\n\n"):""}</div>
          <button className="btn bs" style={{width:"100%",justifyContent:"center",marginTop:12}} onClick={downloadAllZip} disabled={zipLoading}>{zipLoading?"⏳ Preparando ZIP...":"📦 Descargar todo (audio + clips, por escena)"}</button>
        </div>

        {availableProviders(config).length>0?<div className="card">
          <div style={{fontSize:15,fontWeight:700,marginBottom:12}}>🎙️ Generar audio</div>
          {availableProviders(config).length>1&&<div style={{marginBottom:12}}>
            <label className="lbl">Proveedor de voz</label>
            <select className="inp" value={voiceProvider} onChange={function(e){setVoiceProvider(e.target.value);}}>
              {availableProviders(config).map(function(pr){return <option key={pr.code} value={pr.code}>{pr.label}</option>;})}
            </select>
          </div>}
          <div style={{fontSize:11,color:"#7878a0",marginBottom:10}}>♻️ Si una escena no cambió, se reutiliza el audio ya generado (no gasta créditos).</div>
          {voiceError&&<div className="alert aerr">⚠️ {voiceError}</div>}
          {loadVoices&&<div style={{fontSize:13,color:"#7878a0"}}>Cargando voces...</div>}
          {voices.length>0&&<div>
            <div className="frow">
              <div className="fi" style={{flex:2}}>
                <label className="lbl">Voz</label>
                <select className="inp" value={voiceId} onChange={function(e){setVoiceId(e.target.value);}}>
                  {voices.map(function(v){
                    const lang=v.labels&&(v.labels.language||v.labels.accent);
                    const extra=lang?(" — "+lang):(v.desc?(" — "+v.desc):"");
                    const label=v.name+extra;
                    return <option key={v.voice_id} value={v.voice_id}>{label}</option>;
                  })}
                </select>
              </div>
              <button className="btn bp" onClick={generateAudioFull} disabled={!voiceId}>🎙️ Generar audio de todas las escenas</button>
            </div>
            {voiceProvider!=="eleven"&&voiceId&&<div style={{marginTop:8}}>
              <button className="btn bs" style={{fontSize:12,padding:"5px 12px"}} onClick={previewGeminiVoice} disabled={previewLoading}>{previewLoading?"Generando...":"🔊 Probar esta voz"}</button>
              {previewError&&<div style={{fontSize:12,color:"#e05252",marginTop:6}}>⚠️ {previewError}</div>}
            </div>}
            {(function(){
              const sel=voices.find(function(v){return v.voice_id===voiceId;});
              if(!sel)return null;
              return <div style={{display:"flex",alignItems:"center",gap:10,marginTop:4}}>
                {sel.preview_url&&<audio controls src={sel.preview_url} style={{height:32}}/>}
                {sel.labels&&sel.labels.description&&<span style={{fontSize:12,color:"#7878a0"}}>{sel.labels.description}</span>}
              </div>;
            })()}
          </div>}
        </div>:<div className="alert ainf">💡 Agrega una API Key de voz (ElevenLabs, Gemini o Cartesia) en Configuración para generar audio automáticamente.</div>}

        <div className="card">
          <div style={{fontSize:15,fontWeight:700,marginBottom:12}}>🎵 Música de fondo</div>
          {!config.freesoundKey&&<div className="alert ainf">💡 Agrega tu API Key de Freesound en Configuración para buscar música de fondo automáticamente.</div>}
          {config.freesoundKey&&<div>
            <button className="btn bs" onClick={searchMusicForScript} disabled={loadingMusic}>{loadingMusic?"Buscando...":"🎵 Buscar música para este guion"}</button>
            {musicResults.length>0&&<div style={{marginTop:12}}>
              {musicResults.map(function(m){
                const isSel=selectedMusic&&selectedMusic.id===m.id;
                return <div key={m.id} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:"1px solid #222230"}}>
                  <button className="btn bs" style={{fontSize:11,padding:"4px 10px",background:isSel?"#22c55e":"transparent",color:isSel?"#0a0a0f":"#a0a0c0"}} onClick={function(){setSelectedMusic(isSel?null:m);}}>{isSel?"✓ Elegida":"Elegir"}</button>
                  <span style={{fontSize:12,flex:1}}>{m.name}</span>
                  {m.previews&&m.previews["preview-hq-mp3"]&&<audio controls src={m.previews["preview-hq-mp3"]} style={{height:30,maxWidth:180}}/>}
                </div>;
              })}
            </div>}
          </div>}
        </div>

        {script.escenas&&script.escenas.some(function(e){return getFirstClipPoster(e.numero);})&&<div style={{marginBottom:14}}>
          <span className="lbl">🎞️ Storyboard — coherencia visual entre escenas</span>
          <div style={{display:"flex",gap:6,overflowX:"auto",paddingBottom:6}}>
            {script.escenas.map(function(e){
              const poster=getFirstClipPoster(e.numero);
              return <div key={e.numero} style={{flex:"0 0 auto",width:70}}>
                <div style={{width:70,height:100,borderRadius:8,background:poster?("#000 url("+JSON.stringify(poster).slice(1,-1)+") center/cover"):"#ffffff10",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,color:"#7878a0",overflow:"hidden"}}>{!poster&&"sin clip"}</div>
                <div style={{fontSize:9,color:"#7878a0",textAlign:"center",marginTop:2}}>#{e.numero} {e.tipo}</div>
              </div>;
            })}
          </div>
        </div>}

        {script.escenas&&script.escenas.map(function(e){
          return <div key={e.numero} className="sc">
            <div className="sh">
              <div className="sn" style={{background:sc[e.tipo]||"#6c3fff"}}>{e.numero}</div>
              <div><div style={{fontSize:11,fontWeight:700,color:sc[e.tipo]||"#6c3fff",textTransform:"uppercase"}}>{e.tipo}</div><div style={{fontSize:11,color:"#7878a0"}}>{e.duracion}</div></div>
              {(function(){const r=sugerirRitmo(e.guion);return r?<span style={{fontSize:10,padding:"3px 8px",borderRadius:10,background:"#ffffff10",color:"#a0a0c0",whiteSpace:"nowrap"}}>{r.icon} {r.tipo} · {r.rango}</span>:null;})()}
            </div>
            <span className="lbl">Guion</span>
            <div className="stxt">{e.guion}</div>
            <div style={{display:"flex",justifyContent:"flex-end",marginBottom:10}}><CopyBtn text={e.guion}/></div>
            {availableProviders(config).length>0&&voiceId&&<div style={{marginBottom:10}}>
              <button className="btn bs" style={{fontSize:12,padding:"5px 12px"}} onClick={function(){generateAudioForScene(e);}} disabled={genAudioLoading[e.numero]}>{genAudioLoading[e.numero]?"Generando audio...":"🎙️ Generar audio de esta escena"}</button>
              {genAudio[e.numero]&&<audio controls src={genAudio[e.numero]} style={{width:"100%",marginTop:8}}/>}
            </div>}
            <span className="lbl">Prompt Veo3 / Runway / Sora</span>
            <div className="pbox">{e.prompt_video}</div>
            <div style={{display:"flex",justifyContent:"flex-end",marginBottom:10}}><CopyBtn text={e.prompt_video}/></div>
            <div style={{display:"flex",gap:8,marginBottom:12}}>
              <button className="btn bs" style={{fontSize:12,padding:"5px 12px",background:(videoSource[e.numero]||"stock")==="stock"?"#6c3fff":"transparent",color:(videoSource[e.numero]||"stock")==="stock"?"#fff":"#a0a0c0"}} onClick={function(){setVideoSource(function(p){const np=Object.assign({},p);np[e.numero]="stock";return np;});}}>🎞️ Stock</button>
              <button className="btn bs" style={{fontSize:12,padding:"5px 12px",background:videoSource[e.numero]==="ai"?"#6c3fff":"transparent",color:videoSource[e.numero]==="ai"?"#fff":"#a0a0c0"}} onClick={function(){setVideoSource(function(p){const np=Object.assign({},p);np[e.numero]="ai";return np;});}}>✨ IA generativa</button>
            </div>
            {(videoSource[e.numero]||"stock")==="stock"&&<div>
            <div style={{marginBottom:8}}>
              <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:6}}>
                <button className="btn bs" style={{fontSize:11,padding:"4px 10px",background:(termKind[e.numero]||"literal")==="literal"?"#6c3fff":"transparent",color:(termKind[e.numero]||"literal")==="literal"?"#fff":"#a0a0c0"}} onClick={function(){fetchClips(e,"literal");}}>🔎 Literal</button>
                <button className="btn bs" style={{fontSize:11,padding:"4px 10px",background:termKind[e.numero]==="metaforica"?"#6c3fff":"transparent",color:termKind[e.numero]==="metaforica"?"#fff":"#a0a0c0"}} onClick={function(){fetchClips(e,"metaforica");}}>🎭 Metafórico</button>
                <button className="btn bs" style={{fontSize:11,padding:"4px 10px",background:termKind[e.numero]==="textura"?"#6c3fff":"transparent",color:termKind[e.numero]==="textura"?"#fff":"#a0a0c0"}} onClick={function(){fetchClips(e,"textura");}}>🌫️ Textura</button>
              </div>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span className="lbl" style={{marginBottom:0,fontSize:11}}>{getBusquedaTerm(e,termKind[e.numero]||"literal")}</span>
                <button className="btn bs" style={{fontSize:12,padding:"5px 12px"}} onClick={function(){fetchClips(e);}} disabled={loadClips[e.numero]}>{loadClips[e.numero]?"Buscando...":"🎬 Rebuscar clips"}</button>
              </div>
            </div>
            {loadClips[e.numero]&&<div style={{fontSize:12,color:"#7878a0",marginBottom:8}}>Buscando clips automáticamente...</div>}
            {clips[e.numero]&&(function(){
              const needed=getSceneNeededSeconds(e);
              const selected=getSelectedSeconds(e.numero);
              const covered=selected>=needed;
              return <div style={{fontSize:12,marginBottom:8,color:covered?"#22c55e":"#f0b429",fontWeight:600}}>{covered?"✓ ":"⚠ "}Duración seleccionada: {selected}s / Necesita: {needed}s</div>;
            })()}
            {clips[e.numero]&&<div className="cgrid">
              {clips[e.numero].px&&clips[e.numero].px.slice(0,3).map(function(v,idx){
                const order=getSelectedOrder(e.numero,"px",idx);
                const isDefaultShown=!selectedClip[e.numero]||!selectedClip[e.numero].length;
                const showAsFirst=isDefaultShown&&idx===0;
                const used=order>0||showAsFirst;
                return <div key={v.id} className="ci" style={{border:used?"2px solid #22c55e":"2px solid transparent"}}>
                  <video src={v.video_files&&v.video_files[0]?v.video_files[0].link:""} muted loop controls/>
                  <span className="csrc">Pexels {v.duration?"· "+v.duration+"s":""}</span>
                  <button onClick={function(){toggleClip(e.numero,"px",idx);}} style={{position:"absolute",top:4,left:4,background:used?"#22c55e":"rgba(0,0,0,0.75)",color:used?"#0a0a0f":"white",fontSize:11,fontWeight:700,width:26,height:26,borderRadius:13,border:"none",cursor:"pointer"}}>{order>0?order:(showAsFirst?"1":"+")}</button>
                </div>;
              })}
              {clips[e.numero].pb&&clips[e.numero].pb.slice(0,3).map(function(v,idx){
                const order=getSelectedOrder(e.numero,"pb",idx);
                const used=order>0;
                return <div key={v.id} className="ci" style={{border:used?"2px solid #22c55e":"2px solid transparent"}}>
                  <video src={v.videos&&v.videos.small?v.videos.small.url:""} muted loop controls/>
                  <span className="csrc">Pixabay {v.duration?"· "+v.duration+"s":""}</span>
                  <button onClick={function(){toggleClip(e.numero,"pb",idx);}} style={{position:"absolute",top:4,left:4,background:used?"#22c55e":"rgba(0,0,0,0.75)",color:used?"#0a0a0f":"white",fontSize:11,fontWeight:700,width:26,height:26,borderRadius:13,border:"none",cursor:"pointer"}}>{order>0?order:"+"}</button>
                </div>;
              })}
            </div>}
            {clips[e.numero]&&<div style={{fontSize:11,color:"#7878a0",marginTop:6}}>Toca el número en cada clip para agregarlo en orden (1, 2, 3...) hasta cubrir la duración necesaria. Sin selección se usa el primero.</div>}
            </div>}
            {videoSource[e.numero]==="ai"&&<div>
              <label className="btn bs" style={{cursor:"pointer",fontSize:12,display:"inline-flex"}}>
                📤 Subir clip generado
                <input type="file" accept="video/*" style={{display:"none"}} onChange={function(evt){handleCustomClipUpload(evt,e.numero);}}/>
              </label>
              {customClip[e.numero]?<div style={{marginTop:10}}>
                <video src={customClip[e.numero].url} controls style={{width:"100%",borderRadius:8}}/>
                <div style={{fontSize:11,color:"#22c55e",marginTop:4}}>✓ {customClip[e.numero].name}</div>
              </div>:<div style={{fontSize:12,color:"#7878a0",marginTop:8,lineHeight:1.6}}>Genera el clip pegando el prompt de arriba en Flow, Leonardo u otra IA de video, descargalo, y subilo aca.</div>}
            </div>}
            <button className="btn bs" style={{width:"100%",justifyContent:"center",marginTop:14,fontSize:12}} onClick={function(){downloadSceneZip(e);}} disabled={zipLoading}>{zipLoading?"⏳ Preparando...":"📦 Descargar esta escena (audio + clips)"}</button>
          </div>;
        })}
        <div className="card">
          <span className="lbl">Script completo</span>
          <div className="stxt" style={{marginTop:8}}>{script.escenas?script.escenas.map(function(e){return "["+e.tipo+" - "+e.duracion+"]\n"+e.guion;}).join("\n\n"):""}</div>
        </div>

        <div className="card" style={{borderColor:"#f0b429"}}>
          <div style={{fontSize:15,fontWeight:700,marginBottom:10}}>🎬 Ensamblar video final</div>
          <div style={{fontSize:12,color:"#7878a0",marginBottom:14,lineHeight:1.6}}>Une los clips seleccionados con el audio en un solo video MP4 descargable, directamente en tu navegador.</div>
          <div className="alert ainf" style={{fontSize:12}}>⚠️ Esta función procesa video dentro del navegador. Funciona mejor en computadora. En celular puede ser lenta o fallar por memoria limitada — usa wifi y no cambies de app mientras procesa.</div>
          {assembleError&&<div className="alert aerr">⚠️ {assembleError}</div>}
          {!assembling&&!assembledUrl&&<button className="btn bg" onClick={function(){setShowAssembleWarning(true);}} style={{width:"100%",justifyContent:"center"}}>🎬 Ensamblar video</button>}
          {assembling&&<div className="loader"><div className="spin"/><span>{assembleProgress||"Procesando..."}</span></div>}
          {assembledUrl&&<div>
            <video controls src={assembledUrl} style={{width:"100%",borderRadius:10,marginBottom:12}}/>
            <div style={{fontSize:12,color:"#7878a0",marginBottom:10}}>Revisa el video antes de publicarlo. Descargarlo es opcional.</div>
            <a href={assembledUrl} download="viralscript-short.mp4" className="btn bs" style={{width:"100%",justifyContent:"center",textDecoration:"none",marginBottom:10}}>⬇️ Descargar video (opcional)</a>
            {config.ytRefreshToken?<div>
              {!publishResult&&<button className="btn bp" onClick={publishVideo} disabled={publishing} style={{width:"100%",justifyContent:"center"}}>{publishing?"⏳ Publicando...":"📤 Publicar en YouTube (privado)"}</button>}
              {publishError&&<div className="alert aerr" style={{marginTop:10}}>⚠️ {publishError}</div>}
              {publishResult&&<div className="alert aok" style={{marginTop:10}}>✓ Subido como privado — <a href={publishResult.url} target="_blank" rel="noreferrer" style={{color:"#22c55e"}}>revísalo aquí</a> antes de hacerlo público</div>}
            </div>:<div className="alert ainf" style={{fontSize:12}}>💡 Conecta este canal con YouTube (en Configuración → editar canal) para poder publicar directo.</div>}
          </div>}
        </div>

        {showAssembleWarning&&<div className="modal" onClick={function(){setShowAssembleWarning(false);}}>
          <div className="modalbox" onClick={function(e){e.stopPropagation();}}>
            <div style={{fontSize:17,fontWeight:700,marginBottom:14}}>⚠️ Antes de continuar</div>
            <div style={{fontSize:13,color:"#e8e8f0",lineHeight:1.7,marginBottom:20}}>
              El ensamblado de video corre dentro de tu navegador y consume bastante memoria y batería. En computadora suele tardar 10-30 segundos para un Short. En celular puede tardar más o incluso fallar si la memoria es limitada.<br/><br/>
              Recomendaciones:<br/>
              • Usa wifi, no datos móviles<br/>
              • No cambies de app mientras procesa<br/>
              • Si falla, prueba desde una computadora
            </div>
            <div style={{display:"flex",gap:10}}>
              <button className="btn bs" style={{flex:1,justifyContent:"center"}} onClick={function(){setShowAssembleWarning(false);}}>Cancelar</button>
              <button className="btn bg" style={{flex:1,justifyContent:"center"}} onClick={runAssembly}>Continuar</button>
            </div>
          </div>
        </div>}
      </div>}
    </div>
  );
      }
const LONGFORM_HISTORY_KEY="viralscript_longform_history";
function loadLongformHistory(){
  try{const raw=localStorage.getItem(LONGFORM_HISTORY_KEY);return raw?JSON.parse(raw):[];}catch(e){return [];}
}
function saveToLongformHistory(script){
  try{
    const list=loadLongformHistory();
    list.unshift({id:Date.now(),titulo:script.titulo,fecha:new Date().toISOString(),script:script});
    const trimmed=list.slice(0,15);
    localStorage.setItem(LONGFORM_HISTORY_KEY,JSON.stringify(trimmed));
  }catch(e){}
}
function deleteFromLongformHistory(id){
  try{
    const list=loadLongformHistory().filter(function(h){return h.id!==id;});
    localStorage.setItem(LONGFORM_HISTORY_KEY,JSON.stringify(list));
    return list;
  }catch(e){return [];}
}

function LongFormPage(props){
  const config = props.config;
  const [mode,setMode]=useState("ai");
  const [topic,setTopic]=useState("");
  const [duration,setDuration]=useState("30");
  const [lang,setLang]=useState(config.language);
  const [style,setStyle]=useState(config.style);
  const [characterStyle,setCharacterStyle]=useState("");
  const [ownScript,setOwnScript]=useState("");
  const [ownAudioName,setOwnAudioName]=useState("");
  const [ownAudioUrl,setOwnAudioUrl]=useState("");
  const [loading,setLoading]=useState(false);
  const [loadingStep,setLoadingStep]=useState("");
  const [error,setError]=useState("");
  const [script,setScript]=useState(function(){
    const h=loadLongformHistory();
    return h.length?h[0].script:null;
  });
  const [restoredFromHistory,setRestoredFromHistory]=useState(function(){
    const h=loadLongformHistory();
    return h.length>0;
  });
  const [showHistory,setShowHistory]=useState(false);
  const [history,setHistory]=useState(function(){return loadLongformHistory();});
  const [clips,setClips]=useState({});
  const [loadClips,setLoadClips]=useState({});
  const [selectedClip,setSelectedClip]=useState({});
  const [assembling,setAssembling]=useState(false);
  const [assembleProgress,setAssembleProgress]=useState("");
  const [assembledUrl,setAssembledUrl]=useState("");
  const [assembleError,setAssembleError]=useState("");
  const [showAssembleWarning,setShowAssembleWarning]=useState(false);
  const [videoSource,setVideoSource]=useState({});
  const [customClip,setCustomClip]=useState({});
  const [open,setOpen]=useState(1);
  const [musicResults,setMusicResults]=useState([]);
  const [selectedMusic,setSelectedMusic]=useState(null);
  const [loadingMusic,setLoadingMusic]=useState(false);
  const [publishing,setPublishing]=useState(false);
  const [publishResult,setPublishResult]=useState(null);
  const [publishError,setPublishError]=useState("");

  const [voiceProvider,setVoiceProvider]=useState(defaultProvider(config));
  const [voices,setVoices]=useState([]);
  const [voiceId,setVoiceId]=useState("");
  const [loadVoices,setLoadVoices]=useState(false);
  const [voiceError,setVoiceError]=useState("");
  const [previewLoading,setPreviewLoading]=useState(false);
  const [previewError,setPreviewError]=useState("");
  const [genAudio,setGenAudio]=useState({});
  const [termKind,setTermKind]=useState({});
  const [discloseAI,setDiscloseAI]=useState(true);
  const [structWarning,setStructWarning]=useState("");
  const [paletteNote,setPaletteNote]=useState("");
  const [genAudioLoading,setGenAudioLoading]=useState({});

  useEffect(function(){
    setVoiceError("");
    setVoices([]);
    setVoiceId("");
    const prov=VOICE_PROVIDERS.find(function(pr){return pr.code===voiceProvider;});
    if(prov&&config[prov.key]){
      setLoadVoices(true);
      loadVoicesFor(voiceProvider,config).then(function(v){
        setVoices(v);
        if(v.length)setVoiceId(v[0].voice_id);
        setLoadVoices(false);
      }).catch(function(){setVoiceError("No se pudo conectar con "+prov.label+". Verifica tu API key.");setLoadVoices(false);});
    }
  },[config.elevenlabsKey,config.geminiKey,config.cartesiaKey,config.language,voiceProvider]);

  const autoFetchAllClips=async function(scr){
    if(!scr||!scr.escenas)return;
    for(const e of scr.escenas){
      fetchClips(e);
    }
  };

  useEffect(function(){
    if(script)autoFetchAllClips(script);
  },[]);

  const publishVideo=async function(){
    setPublishing(true);setPublishError("");setPublishResult(null);
    try{
      const blob=await (await fetch(assembledUrl)).blob();
      const result=await uploadToYouTube(blob,{
        title:script.titulo,
        description:script.descripcion||"",
        privacyStatus:"private",
      },config);
      setPublishResult(result);
    }catch(err){setPublishError(err.message);}
    setPublishing(false);
  };

  const previewVoice=async function(){
    setPreviewLoading(true);setPreviewError("");
    try{
      const audioUrl=await speak(voiceProvider,"Hola, asi suena mi voz.",voiceId,config);
      const audio=new Audio(audioUrl);
      audio.play();
    }catch(err){setPreviewError(err.message);}
    setPreviewLoading(false);
  };

  const generateAudioForScene=async function(e){
    setGenAudioLoading(function(p){const np=Object.assign({},p);np[e.numero]=true;return np;});
    try{
      const cleanGuion=stripVoiceMarkers(e.guion);const audioUrl=await speak(voiceProvider,cleanGuion,voiceId,config);
      setGenAudio(function(p){const np=Object.assign({},p);np[e.numero]=audioUrl;return np;});
    }catch(err){setError(err.message);}
    setGenAudioLoading(function(p){const np=Object.assign({},p);np[e.numero]=false;return np;});
  };

  const generateAudioFull=async function(){
    if(!script||!script.escenas)return;
    for(const e of script.escenas){
      await generateAudioForScene(e);
    }
  };

  const searchMusicForScript=async function(){
    if(!script||!config.freesoundKey)return;
    setLoadingMusic(true);
    try{
      const q=(script.palabras_clave&&script.palabras_clave[0])||script.titulo||"ambient";
      const results=await searchFreesoundMusic(q,config);
      setMusicResults(results);
    }catch(err){}
    setLoadingMusic(false);
  };

  const generate=async function(){
    if(!topic.trim())return;
    setLoading(true);setError("");setScript(null);setClips({});setRestoredFromHistory(false);setStructWarning("");
    acquireWakeLock();
    try{
      const lObj=LANGUAGES.find(function(l){return l.code===lang;});
      const lL=lObj?lObj.label:"español neutro";
      const sObj=STYLES.find(function(s){return s.code===style;});
      const sL=sObj?sObj.label:"reflexivo";
      const durNum=parseInt(duration);
      const n=durNum>=60?8:durNum>=45?6:durNum>=30?5:durNum>=20?4:durNum>=15?3:2;
      const charLine=characterStyle.trim()?("\nIMPORTANTE: en TODOS los prompt_video, incluye siempre este mismo personaje o estilo visual para mantener consistencia entre escenas: \""+characterStyle.trim()+"\". Integralo naturalmente en la descripcion del sujeto de cada escena."):"";
      const recentHooks=history.slice(0,3).map(function(h){return h.script&&h.script.escenas&&h.script.escenas[0]?h.script.escenas[0].guion:"";}).filter(function(t){return t;});
      const varLine=recentHooks.length?("\nIMPORTANTE - VARIACION: tus ultimos videos de este canal empezaron asi (NO repitas la misma estructura de apertura, palabras ni angulo): "+recentHooks.map(function(t){return JSON.stringify(t.slice(0,140));}).join(" | ")+". El gancho de este nuevo video debe sentirse claramente distinto."):"";
      const prompt="Sos un guionista experto de YouTube especializado en retencion. Crea la estructura y el guion completo de un video de "+duration+" minutos sobre: "+JSON.stringify(topic)+"\nIdioma: "+lL+", Estilo: "+sL+", "+n+" escenas, canal faceless (voz en off, sin rostro en camara).\n\nREGLAS DE ESCRITURA QUE DEBES APLICAR SIEMPRE:\n1. Gancho (primera escena, tipo INTRO): debe ser la linea mas poderosa del video. Genera una promesa clara o abre un bucle que el espectador necesite cerrar. Nada de frases gastadas como 'no vas a creer lo que va a pasar'.\n2. La danza (contexto y conflicto): nunca encadenes ideas con 'y... y... y...'. Usa conectores de tension: 'pero' para introducir conflicto, 'por lo tanto' para mostrar consecuencia, 'sin embargo' para generar un giro. Cada escena debe abrir un bucle nuevo antes de cerrar el anterior.\n3. Reenganche a mitad: en la escena central del desarrollo, introduce un giro, un dato inesperado o una pregunta abierta que reactive la curiosidad. No dependas solo del gancho inicial para sostener la atencion.\n4. Ritmo: varia deliberadamente la longitud de las oraciones, no todas cortas ni todas largas. Marca pausas dramaticas con [pausa] donde corresponda dentro del texto de 'guion'.\n5. Enfasis: marca con [enfasis] las palabras o frases clave donde la voz deberia subir el tono o bajar la velocidad.\n6. Personalidad: el guion debe tener un punto de vista unico. Prohibido el formato generico tipo 'X tips para Y' o 'X formas de'. Encuentra un angulo propio o una metafora central que lo diferencie.\n7. Cierre (ultima escena, tipo CIERRE): el punto mas impactante del video va al final, no enterrado en el medio. Construye hacia ese momento desde el inicio y conecta con el gancho, dejando una idea que se quede en la cabeza del espectador.\n\nPara prompt_video escribe un prompt cinematografico en ingles en un solo parrafo fluido que cubra en este orden: tipo de plano, sujeto y su apariencia, entorno y ambiente, mood/energia, accion especifica, iluminacion, y estilo visual. No uses corchetes ni etiquetas, solo texto natural listo para pegar en Veo3, Runway o Sora."+charLine+buildChannelStyleLine(config)+"\nPara busqueda_clip genera 3 variantes en ingles para buscar stock footage: 'literal' (accion+contexto+movimiento especifico), 'metaforica' (imagen simbolica que represente la idea sin mostrarla literalmente), y 'textura' (plano de ambiente/textura abstracta como conector visual). IMPORTANTE: mantene coherencia de paleta de color y atmosfera visual entre escenas consecutivas a lo largo de todo el video, como si fueran parte del mismo cortometraje, evitando saltos bruscos de tono."+varLine+"\n\nResponde SOLO en JSON valido:\n{\"titulo\":\"titulo SEO\",\"descripcion\":\"texto 150 palabras\",\"duracion_total\":\""+duration+" minutos\",\"palabras_clave\":[\"kw1\",\"kw2\",\"kw3\",\"kw4\",\"kw5\"],\"escenas\":[{\"numero\":1,\"tipo\":\"INTRO\",\"titulo_bloque\":\"texto\",\"duracion\":\"X min\",\"guion\":\"minimo 100 palabras, con marcadores [pausa] y [enfasis] donde corresponda\",\"prompt_video\":\"prompt ingles detallado\",\"busqueda_clip\":{\"literal\":\"keyword ingles\",\"metaforica\":\"keyword ingles\",\"textura\":\"keyword ingles\"}}]}\nTipos: INTRO, DESARROLLO, CIERRE. Solo JSON sin markdown.";
      const text=await callClaude(prompt,config);
            const finalScript=parseAIJson(text);
      setScript(finalScript);
      const openingNew=finalScript.escenas&&finalScript.escenas[0]?finalScript.escenas[0].guion:"";
      let maxSim=0;
      recentHooks.forEach(function(t){const s=textSimilarity(openingNew,t);if(s>maxSim)maxSim=s;});
      setStructWarning(maxSim>0.45?("⚠️ El gancho de este video se parece bastante a uno de tus ultimos videos ("+Math.round(maxSim*100)+"% de palabras clave en comun). Considera regenerar para un angulo mas distinto."):"");
      setOpen(1);
      saveToLongformHistory(finalScript);
      setHistory(loadLongformHistory());
      autoFetchAllClips(finalScript);
    }catch(e){setError(e.message||"Error generando. Verifica tu Anthropic API key.");}
    setLoading(false);
    releaseWakeLock();
  };

  const useOwnScript=async function(){
    if(!ownScript.trim())return;
    setLoading(true);setError("");setScript(null);setClips({});setRestoredFromHistory(false);
    acquireWakeLock();
    try{
      const prompt="Toma este guion de video largo escrito por el usuario y dividelo en escenas (INTRO, DESARROLLO, CIERRE) sin modificar el texto original, solo organizandolo en bloques logicos segun los cambios de tema o parrafo. Para cada escena inventa un titulo_bloque corto. Para prompt_video escribe un prompt cinematografico en ingles en un solo parrafo fluido que cubra tipo de plano, sujeto y apariencia, entorno, mood, accion, iluminacion y estilo visual, sin corchetes, listo para pegar en Veo3, Runway o Sora. Para busqueda_clip genera 3 variantes en ingles para buscar stock footage: 'literal' (accion+contexto+movimiento especifico), 'metaforica' (imagen simbolica que represente la idea sin mostrarla literalmente), y 'textura' (plano de ambiente/textura abstracta como conector visual). Mantene coherencia de paleta de color y atmosfera entre escenas consecutivas.\nGUION DEL USUARIO:\n"+ownScript+"\n\nResponde SOLO JSON:\n{\"titulo\":\"titulo corto basado en el guion\",\"descripcion\":\"resumen breve\",\"duracion_total\":\"estimado\",\"palabras_clave\":[\"kw1\",\"kw2\",\"kw3\"],\"escenas\":[{\"numero\":1,\"tipo\":\"INTRO\",\"titulo_bloque\":\"texto\",\"duracion\":\"estimado\",\"guion\":\"texto exacto del usuario para este bloque\",\"prompt_video\":\"prompt ingles\",\"busqueda_clip\":{\"literal\":\"keyword ingles\",\"metaforica\":\"keyword ingles\",\"textura\":\"keyword ingles\"}}]}\nDivide en tantas escenas como haga falta segun el contenido. Solo JSON sin markdown.";
      const text=await callClaude(prompt,config);
            const finalScript=parseAIJson(text);
      setScript(finalScript);
      setOpen(1);
      saveToLongformHistory(finalScript);
      setHistory(loadLongformHistory());
      autoFetchAllClips(finalScript);
    }catch(e){setError(e.message||"Error organizando el guion. Verifica tu Anthropic API key.");}
    setLoading(false);
    releaseWakeLock();
  };

  const fetchClips=async function(e,termKindArg){
    const tk=termKindArg||termKind[e.numero]||"literal";
    const q=getBusquedaTerm(e,tk);
    setTermKind(function(p){const np=Object.assign({},p);np[e.numero]=tk;return np;});
    setLoadClips(function(p){const np=Object.assign({},p);np[e.numero]=true;return np;});
    try{
      const results=await Promise.all([searchPexels(q,config),config.pixabayKey?searchPixabay(q,config):Promise.resolve([])]);
      setClips(function(p){const np=Object.assign({},p);np[e.numero]={px:results[0],pb:results[1]};return np;});
    }catch(err){}
    setLoadClips(function(p){const np=Object.assign({},p);np[e.numero]=false;return np;});
  };

  const getClipKey=function(src,idx){return src+"_"+idx;};

  const toggleClip=function(numero,src,idx){
    setSelectedClip(function(p){
      const np=Object.assign({},p);
      const list=(np[numero]||[]).slice();
      const key=getClipKey(src,idx);
      const pos=list.indexOf(key);
      if(pos>=0)list.splice(pos,1);else list.push(key);
      np[numero]=list;
      return np;
    });
  };
  const getSelectedOrder=function(numero,src,idx){
    const list=selectedClip[numero];
    if(!list)return 0;
    const key=getClipKey(src,idx);
    const pos=list.indexOf(key);
    return pos>=0?pos+1:0;
  };
  const getClipDuration=function(numero,src,idx){
    const cl=clips[numero];
    if(!cl)return 0;
    if(src==="px"&&cl.px&&cl.px[idx])return cl.px[idx].duration||8;
    if(src==="pb"&&cl.pb&&cl.pb[idx])return cl.pb[idx].duration||8;
    return 8;
  };
  const getSceneNeededSeconds=function(e){
    const d=e.duracion||"";
    const m=d.match(/([\d.]+)/g);
    if(!m)return 20;
    const nums=m.map(Number);
    const val=nums.length>1?Math.max.apply(null,nums):nums[0];
    return /min/i.test(d)?Math.round(val*60):Math.round(val);
  };
  const getSelectedSeconds=function(numero){
    const list=selectedClip[numero];
    if(!list||!list.length)return 0;
    let total=0;
    list.forEach(function(key){
      const us=key.lastIndexOf("_");
      const src=key.slice(0,us);
      const idx=parseInt(key.slice(us+1));
      total+=getClipDuration(numero,src,idx);
    });
    return total;
  };
  const runAssembly=async function(){
    setShowAssembleWarning(false);
    setAssembling(true);setAssembleError("");setAssembledUrl("");
    try{
      if(!script||!script.escenas)throw new Error("No hay guion generado.");
      const clipList=[];
      for(const e of script.escenas){
        const urls=pickClipUrls(e.numero);
        if(!urls.length)throw new Error("Falta un clip para la escena "+e.numero+". Selecciona al menos un clip primero.");
        urls.forEach(function(u){clipList.push({url:u});});
      }
      let audioSrc=ownAudioUrl||"";
      if(!audioSrc){
        const first=script.escenas[0];
        if(genAudio[first.numero])audioSrc=genAudio[first.numero];
      }
      const resultUrl=await assembleVideo(
        clipList,
        audioSrc,
        config.logo||null,
        selectedMusic?selectedMusic.previews["preview-hq-mp3"]:null,
        function(msg){setAssembleProgress(msg);}
      );
      setAssembledUrl(resultUrl);
    }catch(e){setAssembleError(e.message||"Error ensamblando el video.");}
    setAssembling(false);setAssembleProgress("");
  };

  const handleAudioUpload=function(ev){
    const file=ev.target.files&&ev.target.files[0];
    if(!file)return;
    setOwnAudioName(file.name);
    const url=URL.createObjectURL(file);
    setOwnAudioUrl(url);
  };

  const handleCustomClipUpload=function(evt,numero){
    const file=evt.target.files[0];
    if(!file)return;
    const url=URL.createObjectURL(file);
    setCustomClip(function(p){const np=Object.assign({},p);np[numero]={url:url,name:file.name};return np;});
  };

  const getFirstClipPoster=function(numero){
    const cl=clips[numero];
    if(!cl)return null;
    const list=selectedClip[numero];
    let src="px",idx=0;
    if(list&&list.length){
      const us=list[0].lastIndexOf("_");
      src=list[0].slice(0,us);
      idx=parseInt(list[0].slice(us+1));
    }
    const v=src==="px"?(cl.px&&cl.px[idx]):(cl.pb&&cl.pb[idx]);
    if(!v)return null;
    if(src==="px")return v.image||null;
    return v.picture_id?("https://i.vimeocdn.com/video/"+v.picture_id+"_295x166.jpg"):null;
  };
  const pickClipUrls=function(numero){
    if(customClip[numero])return [customClip[numero].url];
    const list=selectedClip[numero];
    const cl=clips[numero];
    if(!cl)return [];
    if(list&&list.length){
      return list.map(function(key){
        const us=key.lastIndexOf("_");
        const src=key.slice(0,us);
        const idx=parseInt(key.slice(us+1));
        if(src==="px"&&cl.px&&cl.px[idx])return cl.px[idx].video_files&&cl.px[idx].video_files[0]?cl.px[idx].video_files[0].link:null;
        if(src==="pb"&&cl.pb&&cl.pb[idx])return cl.pb[idx].videos&&cl.pb[idx].videos.small?cl.pb[idx].videos.small.url:null;
        return null;
      }).filter(Boolean);
    }
    if(cl.px&&cl.px[0])return [cl.px[0].video_files&&cl.px[0].video_files[0]?cl.px[0].video_files[0].link:null].filter(Boolean);
    if(cl.pb&&cl.pb[0])return [cl.pb[0].videos&&cl.pb[0].videos.small?cl.pb[0].videos.small.url:null].filter(Boolean);
    return [];
  };

  const [zipLoading,setZipLoading]=useState(false);

  const downloadSceneZip=async function(e){
    setZipLoading(true);
    try{
      const entries=[{text:e.guion,path:"guion.txt"}];
      const audioUrl=genAudio[e.numero];
      if(audioUrl)entries.push({url:audioUrl,path:"audio."+extFromUrl(audioUrl)});
      const clipUrls=pickClipUrls(e.numero);
      clipUrls.forEach(function(u,i){entries.push({url:u,path:"clip_"+(i+1)+"."+extFromUrl(u)});});
      await buildZip(entries,"bloque_"+padNum(e.numero)+"_"+e.tipo+".zip");
    }catch(err){}
    setZipLoading(false);
  };

  const downloadAllZip=async function(){
    if(!script||!script.escenas)return;
    setZipLoading(true);
    try{
      const entries=[];
      if(discloseAI)entries.push({text:"RECORDATORIO DE DIVULGACION - YouTube\n\nEste video fue producido con voz generada por IA. Antes de publicar:\n1. En YouTube Studio, ve a Detalles del video - Mas opciones.\n2. Activa el interruptor Contenido alterado o sintetico.\n3. Marca la opcion correspondiente a voz o audio generado por IA.\n\nEsto no afecta la monetizacion ni el alcance del video, pero evita strikes de la plataforma por incumplimiento de politicas de divulgacion (Inauthentic Content Policy, 2026)."+(paletteNote?("\n\nPaleta / tono visual definido para este video: "+paletteNote):""),path:"recordatorio_divulgacion.txt"});
      const audioUrlsOrdenados=[];
      for(const e of script.escenas){
        const folder="bloque_"+padNum(e.numero)+"_"+e.tipo+"/";
        entries.push({text:e.guion,path:folder+"guion.txt"});
        const audioUrl=genAudio[e.numero];
        if(audioUrl){entries.push({url:audioUrl,path:folder+"audio."+extFromUrl(audioUrl)});audioUrlsOrdenados.push(audioUrl);}
        const clipUrls=pickClipUrls(e.numero);
        clipUrls.forEach(function(u,i){entries.push({url:u,path:folder+"clip_"+(i+1)+"."+extFromUrl(u)});});
      }
      if(ownAudioUrl){
        entries.push({url:ownAudioUrl,path:"audio_completo."+extFromUrl(ownAudioUrl)});
      }else if(audioUrlsOrdenados.length>0){
        const wavBlob=await concatAudioToWav(audioUrlsOrdenados);
        if(wavBlob)entries.push({blob:wavBlob,path:"audio_completo.wav"});
      }
      await buildZip(entries,(script.titulo||"video_largo")+".zip");
    }catch(err){}
    setZipLoading(false);
  };

  const sc={INTRO:"#f0b429",DESARROLLO:"#6c3fff",CIERRE:"#22c55e"};
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
        <div>
          <div className="ptitle">📽️ Videos Largos</div>
          <div className="psub">Script por escenas con prompts y clips para 10-60 minutos.</div>
        </div>
        <button className="btn bs" style={{fontSize:12,padding:"6px 12px",whiteSpace:"nowrap"}} onClick={function(){setHistory(loadLongformHistory());setShowHistory(true);}}>🕒 Historial ({history.length})</button>
      </div>

      {showHistory&&<div className="modal" onClick={function(){setShowHistory(false);}}>
        <div className="modalbox" onClick={function(e){e.stopPropagation();}}>
          <div style={{fontSize:17,fontWeight:700,marginBottom:14}}>🕒 Historial de videos</div>
          {history.length===0&&<div style={{fontSize:13,color:"#7878a0"}}>Todavia no generaste ningun video largo.</div>}
          {history.map(function(h){
            const d=new Date(h.fecha);
            const fechaStr=d.toLocaleDateString()+" "+d.toLocaleTimeString().slice(0,5);
            return <div key={h.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 0",borderBottom:"1px solid #2a2a3e"}}>
              <div style={{flex:1,cursor:"pointer"}} onClick={function(){setScript(h.script);autoFetchAllClips(h.script);setShowHistory(false);}}>
                <div style={{fontSize:13,fontWeight:600}}>{h.titulo}</div>
                <div style={{fontSize:11,color:"#7878a0"}}>{fechaStr}</div>
              </div>
              <button onClick={function(){setHistory(deleteFromLongformHistory(h.id));}} style={{background:"transparent",border:"none",color:"#e05252",fontSize:16,cursor:"pointer",padding:"4px 8px"}}>🗑️</button>
            </div>;
          })}
          <button className="btn bs" style={{width:"100%",justifyContent:"center",marginTop:16}} onClick={function(){setShowHistory(false);}}>Cerrar</button>
        </div>
      </div>}

      <div className="tabs">
        <button className={"tab"+(mode==="ai"?" active":"")} onClick={function(){setMode("ai");}}>✨ Generar con IA</button>
        <button className={"tab"+(mode==="own"?" active":"")} onClick={function(){setMode("own");}}>📝 Ya tengo mi guion</button>
      </div>

      {mode==="ai"&&<div className="card">
        <div className="frow">
          <div className="fi" style={{flex:3}}><label className="lbl">Frase o Tema</label><input className="inp" placeholder="La disciplina como camino espiritual..." value={topic} onChange={function(e){setTopic(e.target.value);}}/></div>
          <div className="fi"><label className="lbl">Duración</label><select className="inp" value={duration} onChange={function(e){setDuration(e.target.value);}}>
            <option value="10">10 min</option>
            <option value="15">15 min</option>
            <option value="20">20 min</option>
            <option value="30">30 min</option>
            <option value="45">45 min</option>
            <option value="60">60 min</option>
          </select></div>
          <div className="fi"><label className="lbl">Idioma</label><select className="inp" value={lang} onChange={function(e){setLang(e.target.value);}}>{LANGUAGES.map(function(l){return <option key={l.code} value={l.code}>{l.label}</option>;})}</select></div>
          <div className="fi"><label className="lbl">Estilo</label><select className="inp" value={style} onChange={function(e){setStyle(e.target.value);}}>{STYLES.map(function(s){return <option key={s.code} value={s.code}>{s.label}</option>;})}</select></div>
          <button className="btn bp" onClick={generate} disabled={loading||!topic.trim()} style={{alignSelf:"flex-end"}}>{loading?"⏳":"📽️ Generar"}</button>
        </div>
        <div style={{marginTop:12}}>
          <label className="lbl">Personaje / estilo visual para los clips de IA (opcional)</label>
          <input className="inp" placeholder="Ej: mujer adulta con cabello canoso, estilo documental, luz natural" value={characterStyle} onChange={function(e){setCharacterStyle(e.target.value);}}/>
          <div style={{fontSize:11,color:"#7878a0",marginTop:4}}>Si lo completas, todos los prompts Veo3/Runway/Sora de este video van a describir el mismo personaje o estilo para mantener consistencia visual entre escenas.</div>
        </div>
      </div>}

      {mode==="own"&&<div className="card">
        <label className="lbl">Pega tu guion completo</label>
        <textarea className="inp" style={{minHeight:200,resize:"vertical",fontFamily:"inherit",lineHeight:1.5}} placeholder="Pega aqui tu guion ya escrito..." value={ownScript} onChange={function(e){setOwnScript(e.target.value);}}/>
        <div style={{marginTop:14}}>
          <label className="lbl">Audio propio (opcional)</label>
          <div style={{display:"flex",gap:10,alignItems:"center",flexWrap:"wrap"}}>
            <label className="btn bs" style={{cursor:"pointer"}}>
              🎵 Subir audio
              <input type="file" accept="audio/*" style={{display:"none"}} onChange={handleAudioUpload}/>
            </label>
            {ownAudioName&&<span style={{fontSize:12,color:"#7878a0"}}>{ownAudioName}</span>}
          </div>
          {ownAudioUrl&&<audio controls src={ownAudioUrl} style={{width:"100%",marginTop:10}}/>}
        </div>
        <button className="btn bp" onClick={useOwnScript} disabled={loading||!ownScript.trim()} style={{marginTop:16}}>{loading?"⏳":"📋 Organizar en escenas"}</button>
      </div>}

      {error&&<div className="alert aerr">⚠️ {error}</div>}
      {loading&&<div><div className="loader"><div className="spin"/><span>{loadingStep||"Generando estructura completa..."}</span></div><div style={{fontSize:11,color:"#7878a0",marginTop:-6,marginBottom:10}}>📵 No bloquees la pantalla ni cambies de app mientras genera, puede cortar la conexion.</div></div>}

      {script&&<div>
        {restoredFromHistory&&<div className="alert ainf" style={{fontSize:12,marginBottom:10}}>🕒 Este es tu ultimo video generado, restaurado automaticamente. <span style={{textDecoration:"underline",cursor:"pointer"}} onClick={function(){setHistory(loadLongformHistory());setShowHistory(true);}}>Ver historial completo</span></div>}
        <div className="card" style={{borderColor:"#6c3fff"}}>
          <div style={{fontSize:18,fontWeight:700,marginBottom:8}}>{script.titulo}</div>
          <div style={{fontSize:13,color:"#7878a0",lineHeight:1.6,marginBottom:12}}>{script.descripcion}</div>
          <div className="kwr">{script.palabras_clave&&script.palabras_clave.map(function(kw){return <span key={kw} className="tag ta">{kw}</span>;})}</div>
          <div style={{marginTop:12,display:"flex",gap:10}}><span className="tag tg">⏱ {script.duracion_total}</span><span className="tag tok">{script.escenas?script.escenas.length:0} bloques</span></div>
          {ownAudioUrl&&<audio controls src={ownAudioUrl} style={{width:"100%",marginTop:10}}/>}
          <input className="inp" style={{marginTop:10,fontSize:12}} placeholder="🎨 Paleta / tono visual del video (ej: cálido, desaturado, luz natural) — checklist de referencia al elegir clips" value={paletteNote} onChange={function(ev){setPaletteNote(ev.target.value);}}/>
          <label style={{display:"flex",alignItems:"center",gap:8,marginTop:10,fontSize:12,color:"#a0a0c0",cursor:"pointer"}}>
            <input type="checkbox" checked={discloseAI} onChange={function(ev){setDiscloseAI(ev.target.checked);}}/>
            🏷️ Marcar como contenido alterado/sintetico en YouTube Studio antes de publicar
          </label>
          {discloseAI&&<div className="alert ainf" style={{fontSize:11,marginTop:8}}>Recordatorio: en YouTube Studio → Detalles del video → Mas opciones, activa "Contenido alterado o sintetico" (voz generada por IA). Esto no afecta la monetizacion ni el alcance, pero evita strikes por incumplimiento de divulgacion.</div>}
          {structWarning&&<div className="alert aerr" style={{fontSize:11,marginTop:8}}>{structWarning}</div>}
        </div>

        <div className="card">
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span className="lbl">Guion completo</span>
            <button className="btn bs" style={{fontSize:12,padding:"4px 10px"}} onClick={function(){const full=script.escenas?script.escenas.map(function(e){return "["+e.tipo+" — "+e.titulo_bloque+"]\n"+e.guion;}).join("\n\n─────────────────────\n\n"):"";navigator.clipboard.writeText(full);}}>📋 Copiar todo</button>
          </div>
          <div className="stxt" style={{marginTop:8,whiteSpace:"pre-wrap"}}>{script.escenas?script.escenas.map(function(e){return "["+e.tipo+" — "+e.titulo_bloque+"]\n"+e.guion;}).join("\n\n─────────────────────\n\n"):""}</div>
          <button className="btn bs" style={{width:"100%",justifyContent:"center",marginTop:12}} onClick={downloadAllZip} disabled={zipLoading}>{zipLoading?"⏳ Preparando ZIP...":"📦 Descargar todo (audio + clips, por bloque)"}</button>
        </div>

        {availableProviders(config).length>0?<div className="card">
          <div style={{fontSize:15,fontWeight:700,marginBottom:12}}>🎙️ Generar audio</div>
          {availableProviders(config).length>1&&<div style={{marginBottom:12}}>
            <label className="lbl">Proveedor de voz</label>
            <select className="inp" value={voiceProvider} onChange={function(e){setVoiceProvider(e.target.value);}}>
              {availableProviders(config).map(function(pr){return <option key={pr.code} value={pr.code}>{pr.label}</option>;})}
            </select>
          </div>}
          <div style={{fontSize:11,color:"#7878a0",marginBottom:10}}>♻️ Si una escena no cambió, se reutiliza el audio ya generado (no gasta créditos).</div>
          {voiceError&&<div className="alert aerr">⚠️ {voiceError}</div>}
          <div className="frow">
            <div className="fi" style={{flex:2}}>
              <label className="lbl">Voz</label>
              <select className="inp" value={voiceId} onChange={function(e){setVoiceId(e.target.value);}}>
                {voices.map(function(v){
                  const lang2=v.labels&&(v.labels.language||v.labels.accent);
                  const extra=lang2?(" — "+lang2):(v.desc?(" — "+v.desc):"");
                  const label=v.name+extra;
                  return <option key={v.voice_id} value={v.voice_id}>{label}</option>;
                })}
              </select>
            </div>
            <button className="btn bp" onClick={generateAudioFull} disabled={!voiceId}>🎙️ Generar audio de todas las escenas</button>
          </div>
          {voiceProvider!=="eleven"&&voiceId&&<div style={{marginTop:8}}>
            <button className="btn bs" style={{fontSize:12,padding:"5px 12px"}} onClick={previewVoice} disabled={previewLoading}>{previewLoading?"Generando...":"🔊 Probar esta voz"}</button>
            {previewError&&<div style={{fontSize:12,color:"#e05252",marginTop:6}}>⚠️ {previewError}</div>}
          </div>}
        </div>:null}

        <div className="card">
          <div style={{fontSize:15,fontWeight:700,marginBottom:12}}>🎵 Música de fondo</div>
          {!config.freesoundKey&&<div className="alert ainf">💡 Agrega tu API Key de Freesound en Configuración para buscar música de fondo automáticamente.</div>}
          {config.freesoundKey&&<div>
            <button className="btn bs" onClick={searchMusicForScript} disabled={loadingMusic}>{loadingMusic?"Buscando...":"🎵 Buscar música para este video"}</button>
            {musicResults.length>0&&<div style={{marginTop:12}}>
              {musicResults.map(function(m){
                const isSel=selectedMusic&&selectedMusic.id===m.id;
                return <div key={m.id} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:"1px solid #222230"}}>
                  <button className="btn bs" style={{fontSize:11,padding:"4px 10px",background:isSel?"#22c55e":"transparent",color:isSel?"#0a0a0f":"#a0a0c0"}} onClick={function(){setSelectedMusic(isSel?null:m);}}>{isSel?"✓ Elegida":"Elegir"}</button>
                  <span style={{fontSize:12,flex:1}}>{m.name}</span>
                  {m.previews&&m.previews["preview-hq-mp3"]&&<audio controls src={m.previews["preview-hq-mp3"]} style={{height:30,maxWidth:180}}/>}
                </div>;
              })}
            </div>}
          </div>}
        </div>

        {script.escenas&&script.escenas.some(function(e){return getFirstClipPoster(e.numero);})&&<div style={{marginBottom:14}}>
          <span className="lbl">🎞️ Storyboard — coherencia visual entre escenas</span>
          <div style={{display:"flex",gap:6,overflowX:"auto",paddingBottom:6}}>
            {script.escenas.map(function(e){
              const poster=getFirstClipPoster(e.numero);
              return <div key={e.numero} style={{flex:"0 0 auto",width:70}}>
                <div style={{width:70,height:100,borderRadius:8,background:poster?("#000 url("+JSON.stringify(poster).slice(1,-1)+") center/cover"):"#ffffff10",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,color:"#7878a0",overflow:"hidden"}}>{!poster&&"sin clip"}</div>
                <div style={{fontSize:9,color:"#7878a0",textAlign:"center",marginTop:2}}>#{e.numero} {e.tipo}</div>
              </div>;
            })}
          </div>
        </div>}

        {script.escenas&&script.escenas.map(function(e){
          return <div key={e.numero} className="sc">
            <div style={{display:"flex",alignItems:"center",gap:10,cursor:"pointer"}} onClick={function(){setOpen(open===e.numero?null:e.numero);}}>
              <div className="sn" style={{background:sc[e.tipo]||"#6c3fff"}}>{e.numero}</div>
              <div style={{flex:1}}>
                <div style={{fontSize:11,fontWeight:700,color:sc[e.tipo]||"#6c3fff",textTransform:"uppercase"}}>{e.tipo}</div>
                <div style={{fontSize:14,fontWeight:600}}>{e.titulo_bloque}</div>
              </div>
              <div style={{display:"flex",gap:10,alignItems:"center"}}><span className="tag">{e.duracion}</span>{(function(){const r=sugerirRitmo(e.guion);return r?<span style={{fontSize:10,padding:"3px 8px",borderRadius:10,background:"#ffffff10",color:"#a0a0c0",whiteSpace:"nowrap"}}>{r.icon} {r.tipo} · {r.rango}</span>:null;})()}<span style={{color:"#7878a0"}}>{open===e.numero?"▲":"▼"}</span></div>
            </div>
            {open===e.numero&&<div>
              <div style={{marginTop:12}}><span className="lbl">Guion</span><div className="stxt">{e.guion}</div><div style={{display:"flex",justifyContent:"flex-end",marginBottom:12}}><CopyBtn text={e.guion}/></div></div>

              {availableProviders(config).length>0&&voiceId&&<div style={{marginBottom:14}}>
                <button className="btn bs" style={{fontSize:12,padding:"5px 12px"}} onClick={function(){generateAudioForScene(e);}} disabled={genAudioLoading[e.numero]}>{genAudioLoading[e.numero]?"Generando audio...":"🎙️ Generar audio de esta escena"}</button>
                {genAudio[e.numero]&&<audio controls src={genAudio[e.numero]} style={{width:"100%",marginTop:8}}/>}
              </div>}

              <span className="lbl">Prompt Veo3 / Runway / Sora</span>
              <div className="pbox">{e.prompt_video}</div>
              <div style={{display:"flex",justifyContent:"flex-end",marginBottom:10}}><CopyBtn text={e.prompt_video}/></div>

              <div style={{display:"flex",gap:8,marginBottom:12}}>
                <button className="btn bs" style={{fontSize:12,padding:"5px 12px",background:(videoSource[e.numero]||"stock")==="stock"?"#6c3fff":"transparent",color:(videoSource[e.numero]||"stock")==="stock"?"#fff":"#a0a0c0"}} onClick={function(){setVideoSource(function(p){const np=Object.assign({},p);np[e.numero]="stock";return np;});}}>🎞️ Stock</button>
                <button className="btn bs" style={{fontSize:12,padding:"5px 12px",background:videoSource[e.numero]==="ai"?"#6c3fff":"transparent",color:videoSource[e.numero]==="ai"?"#fff":"#a0a0c0"}} onClick={function(){setVideoSource(function(p){const np=Object.assign({},p);np[e.numero]="ai";return np;});}}>✨ IA generativa</button>
              </div>

              {(videoSource[e.numero]||"stock")==="stock"&&<div>
              <div style={{marginBottom:8}}>
                <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:6}}>
                  <button className="btn bs" style={{fontSize:11,padding:"4px 10px",background:(termKind[e.numero]||"literal")==="literal"?"#6c3fff":"transparent",color:(termKind[e.numero]||"literal")==="literal"?"#fff":"#a0a0c0"}} onClick={function(){fetchClips(e,"literal");}}>🔎 Literal</button>
                  <button className="btn bs" style={{fontSize:11,padding:"4px 10px",background:termKind[e.numero]==="metaforica"?"#6c3fff":"transparent",color:termKind[e.numero]==="metaforica"?"#fff":"#a0a0c0"}} onClick={function(){fetchClips(e,"metaforica");}}>🎭 Metafórico</button>
                  <button className="btn bs" style={{fontSize:11,padding:"4px 10px",background:termKind[e.numero]==="textura"?"#6c3fff":"transparent",color:termKind[e.numero]==="textura"?"#fff":"#a0a0c0"}} onClick={function(){fetchClips(e,"textura");}}>🌫️ Textura</button>
                </div>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <span className="lbl" style={{marginBottom:0,fontSize:11}}>{getBusquedaTerm(e,termKind[e.numero]||"literal")}</span>
                  <button className="btn bs" style={{fontSize:12,padding:"5px 12px"}} onClick={function(){fetchClips(e);}} disabled={loadClips[e.numero]}>{loadClips[e.numero]?"Buscando...":"🎬 Rebuscar clips"}</button>
                </div>
              </div>
              {loadClips[e.numero]&&<div style={{fontSize:12,color:"#7878a0",marginBottom:8}}>Buscando clips automaticamente...</div>}
              <div style={{fontSize:11,color:"#7878a0",marginBottom:8}}>Esta escena dura varios minutos: el stock sirve como referencia visual, vas a necesitar varios clips distintos al armar el video final en tu editor.</div>
              {clips[e.numero]&&(function(){
                const needed=getSceneNeededSeconds(e);
                const selected=getSelectedSeconds(e.numero);
                const covered=selected>=needed;
                return <div style={{fontSize:12,marginBottom:8,color:covered?"#22c55e":"#f0b429",fontWeight:600}}>{covered?"✓ ":"⚠ "}Duración seleccionada: {selected}s / Necesita aprox: {needed}s</div>;
              })()}
              {clips[e.numero]&&<div className="cgrid">
                {clips[e.numero].px&&clips[e.numero].px.slice(0,3).map(function(v,idx){
                  const order=getSelectedOrder(e.numero,"px",idx);
                  const used=order>0;
                  return <div key={v.id} className="ci" style={{border:used?"2px solid #22c55e":"2px solid transparent"}}>
                    <video src={v.video_files&&v.video_files[0]?v.video_files[0].link:""} muted loop controls/>
                    <span className="csrc">Pexels {v.duration?"· "+v.duration+"s":""}</span>
                    <button onClick={function(){toggleClip(e.numero,"px",idx);}} style={{position:"absolute",top:4,left:4,background:used?"#22c55e":"rgba(0,0,0,0.75)",color:used?"#0a0a0f":"white",fontSize:11,fontWeight:700,width:26,height:26,borderRadius:13,border:"none",cursor:"pointer"}}>{order>0?order:"+"}</button>
                  </div>;
                })}
                {clips[e.numero].pb&&clips[e.numero].pb.slice(0,3).map(function(v,idx){
                  const order=getSelectedOrder(e.numero,"pb",idx);
                  const used=order>0;
                  return <div key={v.id} className="ci" style={{border:used?"2px solid #22c55e":"2px solid transparent"}}>
                    <video src={v.videos&&v.videos.small?v.videos.small.url:""} muted loop controls/>
                    <span className="csrc">Pixabay {v.duration?"· "+v.duration+"s":""}</span>
                    <button onClick={function(){toggleClip(e.numero,"pb",idx);}} style={{position:"absolute",top:4,left:4,background:used?"#22c55e":"rgba(0,0,0,0.75)",color:used?"#0a0a0f":"white",fontSize:11,fontWeight:700,width:26,height:26,borderRadius:13,border:"none",cursor:"pointer"}}>{order>0?order:"+"}</button>
                  </div>;
                })}
              </div>}
              </div>}
              {videoSource[e.numero]==="ai"&&<div>
                <label className="btn bs" style={{cursor:"pointer",fontSize:12,display:"inline-flex"}}>
                  📤 Subir clip generado
                  <input type="file" accept="video/*" style={{display:"none"}} onChange={function(evt){handleCustomClipUpload(evt,e.numero);}}/>
                </label>
                {customClip[e.numero]?<div style={{marginTop:10}}>
                  <video src={customClip[e.numero].url} controls style={{width:"100%",borderRadius:8}}/>
                  <div style={{fontSize:11,color:"#22c55e",marginTop:4}}>✓ {customClip[e.numero].name}</div>
                </div>:<div style={{fontSize:12,color:"#7878a0",marginTop:8,lineHeight:1.6}}>Genera el clip pegando el prompt de arriba en Flow, Leonardo u otra IA de video, descargalo, y subilo aca.</div>}
              </div>}
            </div>}
            <button className="btn bs" style={{width:"100%",justifyContent:"center",marginTop:14,fontSize:12}} onClick={function(){downloadSceneZip(e);}} disabled={zipLoading}>{zipLoading?"⏳ Preparando...":"📦 Descargar este bloque (audio + clips)"}</button>
          </div>;
        })}

        <div className="card" style={{borderColor:"#f0b429"}}>
          <div style={{fontSize:15,fontWeight:700,marginBottom:10}}>🎬 Ensamblar video final</div>
          <div style={{fontSize:12,color:"#7878a0",marginBottom:14,lineHeight:1.6}}>Une los clips seleccionados de todas las escenas con el audio en un solo video MP4 descargable, directamente en tu navegador.</div>
          <div className="alert ainf" style={{fontSize:12}}>⚠️ Esta funcion procesa video dentro del navegador y en videos largos consume bastante mas memoria y tiempo que en un Short. Funciona mejor en computadora. En celular puede ser lenta o fallar por memoria limitada — usa wifi y no cambies de app mientras procesa. Si falla, arma el video en tu editor con los clips descargados del ZIP.</div>
          {assembleError&&<div className="alert aerr">⚠️ {assembleError}</div>}
          {!assembling&&!assembledUrl&&<button className="btn bg" onClick={function(){setShowAssembleWarning(true);}} style={{width:"100%",justifyContent:"center"}}>🎬 Ensamblar video</button>}
          {assembling&&<div className="loader"><div className="spin"/><span>{assembleProgress||"Procesando..."}</span></div>}
          {assembledUrl&&<div>
            <video controls src={assembledUrl} style={{width:"100%",borderRadius:10,marginBottom:12}}/>
            <div style={{fontSize:12,color:"#7878a0",marginBottom:10}}>Revisa el video antes de publicarlo. Descargarlo es opcional.</div>
            <a href={assembledUrl} download="viralscript-video-largo.mp4" className="btn bs" style={{width:"100%",justifyContent:"center",textDecoration:"none",marginBottom:10}}>⬇️ Descargar video (opcional)</a>
            {config.ytRefreshToken?<div>
              {!publishResult&&<button className="btn bp" onClick={publishVideo} disabled={publishing} style={{width:"100%",justifyContent:"center"}}>{publishing?"⏳ Publicando...":"📤 Publicar en YouTube (privado)"}</button>}
              {publishError&&<div className="alert aerr" style={{marginTop:10}}>⚠️ {publishError}</div>}
              {publishResult&&<div className="alert aok" style={{marginTop:10}}>✓ Subido como privado — <a href={publishResult.url} target="_blank" rel="noreferrer" style={{color:"#22c55e"}}>revísalo aquí</a> antes de hacerlo público</div>}
            </div>:<div className="alert ainf" style={{fontSize:12}}>💡 Conecta este canal con YouTube (en Configuración → editar canal) para poder publicar directo.</div>}
          </div>}
        </div>

        {showAssembleWarning&&<div className="modal" onClick={function(){setShowAssembleWarning(false);}}>
          <div className="modalbox" onClick={function(e){e.stopPropagation();}}>
            <div style={{fontSize:17,fontWeight:700,marginBottom:14}}>⚠️ Antes de continuar</div>
            <div style={{fontSize:13,color:"#e8e8f0",lineHeight:1.7,marginBottom:20}}>
              El ensamblado de video corre dentro de tu navegador y consume bastante memoria y bateria, mas aun en un video largo. Recomendado hacerlo desde computadora.<br/><br/>
              Recomendaciones:<br/>
              • Usa wifi, no datos moviles<br/>
              • No cambies de app mientras procesa<br/>
              • Si falla, prueba desde una computadora o arma el video en tu editor con el ZIP descargado
            </div>
            <div style={{display:"flex",gap:10}}>
              <button className="btn bs" style={{flex:1,justifyContent:"center"}} onClick={function(){setShowAssembleWarning(false);}}>Cancelar</button>
              <button className="btn bg" style={{flex:1,justifyContent:"center"}} onClick={runAssembly}>Continuar</button>
            </div>
          </div>
        </div>}
      </div>}
    </div>
  );
}

export default function App(){
  const [config,setConfig]=useState(null);
  const [page,setPage]=useState("config");
  const [activeChannelTick,setActiveChannelTick]=useState(0);
  useEffect(function(){
    const s=loadConfig();
    if(s&&s.youtubeKey&&s.anthropicKey){setConfig(s);setPage("research");}
  },[]);
  const handleConfig=function(cfg){setConfig(cfg);if(cfg.youtubeKey&&cfg.anthropicKey)setPage("research");};
  const configured=!!(config&&config.youtubeKey&&config.anthropicKey);

  const getEffectiveConfig=function(){
    if(!config)return config;
    const channels=loadChannels();
    const activeId=loadActiveChannelId();
    const active=channels.find(function(c){return c.id===activeId;});
    if(!active)return Object.assign({},config,{language:config.language||"es-latam",style:config.style||"reflexivo",niche:config.niche||"",channelName:config.channelName||"",logo:"",ytRefreshToken:""});
    return Object.assign({},config,{language:active.language,style:active.style,niche:active.niche,channelName:active.name,logo:active.logo||"",ytRefreshToken:active.ytRefreshToken||"",channelTone:active.tone||"",channelRhythm:active.rhythm||"",channelPalette:active.palette||""});
  };
  const effectiveConfig=getEffectiveConfig();

  let pageContent;
  if(page==="config")pageContent=<ConfigPage config={config} setConfig={handleConfig}/>;
  else if(page==="research")pageContent=<ResearchPage config={effectiveConfig}/>;
  else if(page==="analyzer")pageContent=<AnalyzerPage config={effectiveConfig}/>;
  else if(page==="shorts")pageContent=<ShortsPage config={effectiveConfig}/>;
  else if(page==="longform")pageContent=<LongFormPage config={effectiveConfig}/>;
  return(
    <div>
      <style>{css}</style>
      <div className="app">
        <Sidebar page={page} setPage={setPage} configured={configured}/>
        <div className="main">{pageContent}</div>
      </div>
    </div>
  );
        }
